/**
 * نمایش و خروجی لاگ عملیات (Audit)
 * ارتقا: فیلتر، جستجو، خروجی CSV، پاک‌سازی کنترل‌شده
 */

import { auditLog, logAudit, save, verifyAuditIntegrity } from './state';
import { toast, confirmAction } from './ui';
import { formatAuditTime, downloadFile, dateStr, esc } from '@/utils/helpers';
import { rowsToCSV } from './import-export';
import { guardPermission } from './filters-roles';

const ACTION_LABELS: Record<string, string> = {
  count: 'ثبت شمارش کالا', count2: 'ثبت شمارش دوم', undo: 'برگرداندن شمارش',
  import: 'ورود اطلاعات کالا', import_json: 'بازیابی اطلاعات کالا', export_csv: 'دریافت فایل CSV',
  export_json: 'تهیه فایل پشتیبان', export_xlsx: 'دریافت فایل اکسل', export_photos: 'خروجی تصاویر',
  import_photos: 'ورود تصاویر', photo: 'ثبت تصویر کالا', session: 'شروع دوره شمارش',
  close_session: 'پایان دوره شمارش', session_join: 'پیوستن به جلسه شمارش', team_export: 'ارسال اطلاعات برای اعضای تیم',
  team_import: 'دریافت و ادغام اطلاعات تیم', partial_export: 'ارسال بخشی از اطلاعات', merge: 'ادغام اطلاعات',
  product_add: 'افزودن کالا', product_edit: 'ویرایش اطلاعات کالا', product_delete: 'حذف کالا',
  clear_counts: 'پاک‌کردن شمارش‌ها', bulk_zero: 'صفرکردن گروهی موجودی شمارش‌شده', backup: 'تهیه پشتیبان',
  inventory_doc_create: 'ایجاد سند انبار', inventory_doc_approve: 'تأیید سند انبار', audit_log_cleared: 'پاک‌سازی تاریخچه عملیات',
  export_audit: 'دریافت گزارش فعالیت‌ها', team_online_sync: 'همگام‌سازی اطلاعات تیم',
  stock_synced_from_costing_truth: 'هماهنگ‌سازی موجودی با سوابق بهای تمام‌شده',
  stock_qty_synced_to_costing: 'هماهنگ‌سازی سوابق بهای تمام‌شده با موجودی',
  print_labels: 'چاپ برچسب کالا', apply_system: 'اعمال موجودی مبنا', reset_counts_to_system: 'بازنشانی شمارش بر اساس موجودی مبنا',
  export_counted_products_xlsx: 'دریافت اکسل کالاهای شمارش‌شده', save_accounting_template: 'ذخیره الگوی گزارش حسابداری',
  export_accounting_custom_xlsx: 'دریافت گزارش سفارشی حسابداری', export_stock_alerts_xlsx: 'دریافت اکسل هشدارهای موجودی',
  print_stock_alerts: 'چاپ هشدارهای موجودی', export_stock_alerts_csv: 'دریافت CSV هشدارهای موجودی',
  export_product_cardex: 'دریافت کاردکس کالا', print_product_cardex: 'چاپ کاردکس کالا',
  cheque_endorsed: 'انتقال چک به شخص دیگر', party_upsert: 'ثبت یا ویرایش طرف‌حساب',
  accounting_opening_stock_bulk_valued: 'ثبت ارزش موجودی اول دوره به‌صورت گروهی',
  accounting_opening_stock_valued: 'ثبت ارزش موجودی اول دوره', operating_entry: 'ثبت هزینه یا درآمد',
  inventory_nrv_write_down: 'ثبت کاهش ارزش موجودی', accounting_invoice_draft_edited: 'ویرایش پیش‌نویس فاکتور',
  accounting_invoice_draft_deleted: 'حذف پیش‌نویس فاکتور', accounting_invoice_stock_posted: 'ثبت نهایی فاکتور و گردش موجودی',
  bank_internal_transfer_posted: 'ثبت انتقال وجه بین حساب‌ها', bank_statement_imported: 'دریافت صورت‌حساب بانکی',
  bank_statement_row_matched: 'تطبیق ردیف صورت‌حساب بانکی', bank_cash_deposit: 'واریز وجه به بانک',
  bank_cash_withdraw: 'برداشت وجه از بانک', bank_fee_posted: 'ثبت کارمزد بانکی',
  cheque_chain_transferred: 'انتقال زنجیره‌ای چک', cheque_holder_outcome_recorded: 'ثبت نتیجه چک نزد دارنده',
  factory_reset_financial_operational: 'بازنشانی اطلاعات مالی و عملیاتی', discard_pending_commerce_operation: 'لغو عملیات مالی در انتظار',
  'accounting.chart.account_created': 'ایجاد سرفصل حسابداری', 'accounting.chart.account_updated': 'ویرایش سرفصل حسابداری',
  'accounting.chart.account_removed': 'حذف سرفصل حسابداری', 'accounting.journal.draft_created': 'ایجاد پیش‌نویس سند حسابداری',
  'accounting.journal.draft_updated': 'ویرایش پیش‌نویس سند حسابداری', 'accounting.journal.posted': 'ثبت قطعی سند حسابداری',
  'accounting.journal.reversal_linked': 'ثبت سند برگشت و ارتباط با سند اصلی',
  'accounting.fiscal.active_period_changed': 'تغییر دوره مالی فعال', 'accounting.fiscal.period_created': 'ایجاد دوره مالی',
  'accounting.fiscal.closing_draft_created': 'ایجاد پیش‌نویس سند اختتامیه',
  'accounting.fiscal.opening_draft_created': 'ایجاد پیش‌نویس سند افتتاحیه',
  'accounting.fiscal.year_finalized': 'نهایی‌سازی و بستن سال مالی',
  'accounting.fiscal.close_requested': 'درخواست بستن سال مالی',
  ورود: 'ورود اطلاعات', 'ورود کاربر': 'ورود کاربر به برنامه', 'ورود بیومتریک': 'ورود با اثر انگشت یا تشخیص چهره',
  'خروج کاربر': 'خروج کاربر از برنامه', 'تغییر مجوز کاربر': 'تغییر نقش و دسترسی کاربر',
  'ایجاد کاربر': 'ایجاد حساب کاربری', 'تعریف نقش': 'تعریف نقش جدید', 'ویرایش نقش': 'ویرایش نقش کاربری',
  'حذف نقش': 'حذف نقش کاربری', 'غیرفعال‌سازی کاربر': 'غیرفعال‌کردن حساب کاربری', 'فعال‌سازی کاربر': 'فعال‌کردن حساب کاربری',
  cheque_deposited: 'تحویل چک به بانک', cheque_extended: 'تمدید سررسید چک', cheque_replaced: 'جایگزینی چک',
  cheque_bounced_note: 'ثبت برگشت چک', cheque_cleared_note: 'ثبت وصول چک', cheque_void_note: 'ثبت ابطال چک',
};

function actionLabel(action: string): string {
  if (ACTION_LABELS[action]) return ACTION_LABELS[action];
  // برای رویدادهای جدید، عنوان خوانا تولید می‌شود؛ کد فنی به کاربر نمایش داده نمی‌شود.
  const words = action.replace(/^accounting\./, '').replace(/[._-]+/g, ' ').trim();
  const labels: Record<string, string> = {
    create: 'ایجاد', created: 'ایجاد', update: 'ویرایش', updated: 'ویرایش', edit: 'ویرایش',
    delete: 'حذف', removed: 'حذف', remove: 'حذف', post: 'ثبت', posted: 'ثبت نهایی',
    import: 'ورود', imported: 'ورود', export: 'دریافت خروجی', transferred: 'انتقال',
    matched: 'تطبیق', approved: 'تأیید', approve: 'تأیید', finalized: 'نهایی‌سازی',
    account: 'حساب', journal: 'سند حسابداری', fiscal: 'دوره مالی', bank: 'بانک', cheque: 'چک',
    invoice: 'فاکتور', stock: 'موجودی', statement: 'صورت‌حساب', row: 'ردیف', period: 'دوره',
  };
  const readable = words.split(' ').map((word) => labels[word] || '').filter(Boolean);
  return readable.length ? `عملیات: ${readable.join(' ')}` : 'ثبت فعالیت در برنامه';
}

const DETAIL_LABELS: Record<string, string> = {
  name: 'کالا', code: 'کد کالا', count: 'تعداد موارد', added: 'تعداد افزوده‌شده', updated: 'تعداد ویرایش‌شده',
  skipped: 'تعداد ردشده', matched: 'تعداد تطبیق‌یافته', merged: 'تعداد ادغام‌شده', operator: 'انجام‌دهنده',
  sessionId: 'شناسه جلسه', number: 'شماره سند', kind: 'نوع سند', product: 'کالا', qty: 'مقدار',
  before: 'موجودی قبل', after: 'موجودی بعد', prev: 'مقدار قبلی', next: 'مقدار جدید', restored: 'مقدار بازگردانده‌شده',
  amountRial: 'مبلغ (ریال)', grossRial: 'مبلغ کل (ریال)', oldGrossRial: 'مبلغ قبلی (ریال)', newGrossRial: 'مبلغ جدید (ریال)',
  date: 'تاریخ', startDate: 'تاریخ شروع', endDate: 'تاریخ پایان', title: 'عنوان', description: 'شرح',
  role: 'نقش کاربری', username: 'نام کاربری', permissions: 'تعداد دسترسی‌ها', removedEntries: 'تعداد سوابق پاک‌شده',
  paperSize: 'اندازه کاغذ', phase: 'مرحله شمارش', total: 'تعداد کل', fail: 'تعداد ناموفق', ok: 'تعداد موفق',
  from: 'مبدأ', to: 'مقصد', fee: 'کارمزد (ریال)', feeRial: 'کارمزد (ریال)', rows: 'تعداد ردیف‌ها',
  fields: 'تعداد ستون‌ها', onlyDiff: 'فقط موارد دارای اختلاف', mode: 'روش ورود',
};

function readableValue(value: unknown): string {
  if (value == null || value === '') return '—';
  if (typeof value === 'boolean') return value ? 'بله' : 'خیر';
  if (Array.isArray(value)) return `${value.length.toLocaleString('fa-IR')} مورد`;
  if (typeof value === 'object') return 'جزئیات ثبت شد';
  if (typeof value === 'number') return value.toLocaleString('fa-IR');
  const text = String(value);
  if (/^[a-f0-9-]{24,}$/i.test(text) || /^\d{10,}$/.test(text)) return 'ثبت شد';
  return text.replace(/[0-9]/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[Number(digit)]);
}

function readableDetailValue(key: string, value: unknown): string {
  if (typeof value === 'string' && /date|تاریخ/i.test(key)) {
    // ISO/Gregorian date values are converted to Persian calendar; already-Jalali values stay intact.
    const match = value.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
    if (match && Number(match[1]) >= 1700) {
      const parsed = new Date(`${match[1]}-${match[2].padStart(2, '0')}-${match[3].padStart(2, '0')}T12:00:00`);
      if (Number.isFinite(parsed.getTime())) return new Intl.DateTimeFormat('fa-IR-u-ca-persian-nu-arabext', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(parsed);
    }
  }
  return readableValue(value);
}

function detailText(a: { action: string; detail?: Record<string, unknown> }): string {
  const d = a.detail || {};
  switch (a.action) {
    case 'count': case 'count2': return `${d.name || 'کالا'}: ${readableValue(d.prev)} ← ${readableValue(d.next)}`;
    case 'undo': return `شمارش کالای «${readableValue(d.name || d.summary)}» به ${readableValue(d.restored)} بازگردانده شد`;
    case 'import': case 'import_json': return `${readableValue(d.count ?? d.added ?? 0)} کالا دریافت شد`;
    case 'merge': case 'team_import': return `جدید: ${readableValue(d.added)} · تطبیق‌یافته: ${readableValue(d.matched)} · ادغام‌شده: ${readableValue(d.merged)}`;
    case 'team_export': case 'partial_export': return `${readableValue(d.count ?? 0)} شمارش برای تیم ارسال شد`;
    case 'product_add': case 'product_edit': case 'product_delete': return `${readableValue(d.name)}${d.code ? ` · کد: ${readableValue(d.code)}` : ''}`;
    case 'photo': return `تصویر کالای «${readableValue(d.name)}» ثبت شد`;
    case 'clear_counts': case 'bulk_zero': return `${readableValue(d.count ?? 0)} مورد تحت تأثیر قرار گرفت`;
    case 'session_join': return 'کاربر به جلسه شمارش پیوست';
    case 'audit_log_cleared': return `${readableValue(d.removedEntries)} سابقه پاک شد؛ این رویداد برای ثبت عملیات پاک‌سازی نگهداری شده است`;
    default: {
      const entries = Object.entries(d).filter(([key, value]) => value != null && !/^(id|.*Id|hash|previousHash|integrityHash|sourceDocumentId)$/.test(key));
      if (!entries.length) return 'عملیات با موفقیت ثبت شد';
      return entries.slice(0, 5).map(([key, value]) => `${DETAIL_LABELS[key] || 'اطلاعات تکمیلی'}: ${readableDetailValue(key, value)}`).join(' · ');
    }
  }
}

export function getAuditRows(limit = 200): Array<{
  ts: string;
  action: string;
  label: string;
  detail: string;
  operator: string;
}> {
  const list = [...auditLog].reverse().slice(0, limit);
  return list.map((a) => ({
    ts: a.ts,
    action: a.action,
    label: actionLabel(a.action),
    detail: detailText(a),
    operator: a.operator || '',
  }));
}

export function renderAuditList(containerId = 'auditList', limit = 150): void {
  const el = document.getElementById(containerId);
  if (!el) return;

  const q = (
    (document.getElementById('auditSearch') as HTMLInputElement | null)?.value || ''
  )
    .trim()
    .toLowerCase();

  let rows = getAuditRows(500);
  if (q) {
    rows = rows.filter(
      (r) =>
        r.label.toLowerCase().includes(q) ||
        r.detail.toLowerCase().includes(q) ||
        r.operator.toLowerCase().includes(q) ||
        r.action.toLowerCase().includes(q)
    );
  }
  rows = rows.slice(0, limit);

  if (!rows.length) {
    el.innerHTML = '<p class="hint" style="padding:12px">لاگی برای نمایش نیست.</p>';
    return;
  }

  const integrity = verifyAuditIntegrity();
  const integrityLabel = integrity.valid
    ? `صحت زنجیره: قابل‌تأیید (${integrity.checked} رویداد جدید، ${integrity.legacy} رویداد قدیمی بدون امضا)`
    : `هشدار: ناسازگاری زنجیره در ردیف ${integrity.brokenAt! + 1}`;
  el.innerHTML = `<div class="audit-integrity ${integrity.valid ? 'is-valid' : 'is-broken'}">${esc(integrityLabel)}</div>` + rows
    .map(
      (r) => `
    <div class="audit-item">
      <div class="audit-top">
        <span class="audit-action">${esc(r.label)}</span>
        <span class="audit-time">${esc(formatAuditTime(r.ts))}</span>
      </div>
      <div class="audit-detail">${esc(r.detail)}</div>
      ${r.operator ? `<div class="audit-op">👤 ${esc(r.operator)}</div>` : ''}
    </div>`
    )
    .join('');
}

export function exportAuditCSV(): void {
  if (!guardPermission('audit.read', 'خروجی تاریخچه فعالیت')) return;
  const rows = getAuditRows(2000).map((r) => ({
    زمان: formatAuditTime(r.ts),
    عملیات: r.label,
    جزئیات: r.detail,
    اپراتور: r.operator,
    کد: r.action,
  }));
  if (!rows.length) {
    toast('لاگی نیست', 'info');
    return;
  }
  downloadFile('\uFEFF' + rowsToCSV(rows), `anbar-audit-${dateStr()}.csv`, 'text/csv;charset=utf-8');
  toast('لاگ دانلود شد', 'success');
  logAudit('export_audit', { count: rows.length });
}

export async function clearAuditLog(): Promise<void> {
  if (!guardPermission('audit.clear', 'پاک‌سازی تاریخچه فعالیت')) return;
  if (!(await confirmAction('تمام لاگ عملیات پاک شود؟ این کار برگشت‌ناپذیر است.', { danger: true }))) return;
  const removedEntries = auditLog.length;
  auditLog.length = 0;
  // پاک‌سازی نیز خودش به‌عنوان رویداد جدید ثبت می‌شود تا حذف بی‌ردپا نباشد.
  logAudit('audit_log_cleared', { removedEntries });
  // snapshot کامل برنامه را به‌روز کن.
  save(true);
  const search = document.getElementById('auditSearch') as HTMLInputElement | null;
  if (search) search.value = '';
  renderAuditList();
  toast('لاگ پاک شد', 'success');
}

/** تزریق استایل یک‌بار */
export function ensureAuditStyles(): void {
  if (document.getElementById('audit-styles')) return;
  const st = document.createElement('style');
  st.id = 'audit-styles';
  st.textContent = `
    .audit-integrity{padding:8px 10px;margin:8px 0;border-radius:8px;font-size:.78rem;background:var(--bg-soft, #f5f5f5)}
    .audit-integrity.is-broken{border:1px solid #c33;color:#b42318}
    .audit-integrity.is-valid{border:1px solid var(--border-light)}
    .audit-item{
      padding:10px 12px;border-bottom:1px solid var(--border-light);
    }
    .audit-top{display:flex;justify-content:space-between;gap:8px;align-items:center;flex-wrap:wrap}
    .audit-action{font-weight:800;font-size:.88rem;color:var(--primary-dark)}
    .audit-time{font-size:.72rem;color:var(--text-soft);direction:rtl;unicode-bidi:plaintext;white-space:nowrap;font-variant-numeric:tabular-nums}
    .audit-detail{font-size:.82rem;margin-top:4px;color:var(--text)}
    .audit-op{font-size:.75rem;color:var(--text-soft);margin-top:2px}
    #auditList{max-height:min(50vh,420px);overflow:auto;border:1px solid var(--border-light);border-radius:12px;background:var(--card)}
  `;
  document.head.appendChild(st);
}
