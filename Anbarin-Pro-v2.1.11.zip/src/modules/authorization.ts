/** Local role and permission policy. This is a device-local convenience gate,
 * not a server-side security boundary; a trusted backend must re-check actions. */
import type { AppSettings } from '@/types';

export type AppRole = string;
export interface CustomRole { id: string; name: string; permissions: Permission[]; createdAt: string; updatedAt: string; }
const CUSTOM_ROLES_KEY = 'anbarin_custom_roles_v1';
export function readCustomRoles(): CustomRole[] {
  try { const raw = JSON.parse(localStorage.getItem(CUSTOM_ROLES_KEY) || '[]'); if (!Array.isArray(raw)) return [];
    return raw.filter((r): r is CustomRole => !!r && typeof r.id === 'string' && /^[a-z][a-z0-9_-]{2,39}$/.test(r.id) && typeof r.name === 'string' && Array.isArray(r.permissions))
      .map(r => ({ ...r, permissions: r.permissions.filter((p: unknown): p is Permission => typeof p === 'string' && isKnownPermission(p)) }));
  } catch { return []; }
}
export function writeCustomRoles(roles: CustomRole[]): void { localStorage.setItem(CUSTOM_ROLES_KEY, JSON.stringify(roles)); }
export function roleLabel(role: string): string { return role === 'admin' ? 'مدیر اصلی' : role === 'counter' ? 'شمارنده' : role === 'viewer' ? 'مشاهده‌گر' : readCustomRoles().find(r => r.id === role)?.name || 'نقش ناشناخته'; }
export type Permission =
  | 'inventory.read' | 'inventory.count' | 'inventory.edit' | 'inventory.import' | 'inventory.export'
  | 'session.start' | 'session.close' | 'team.sync' | 'users.manage' | 'roles.assign'
  | 'audit.read' | 'audit.clear' | 'license.manage' | 'settings.manage'
  | 'invoice.read' | 'invoice.create' | 'invoice.edit' | 'invoice.deleteDraft' | 'invoice.post'
  | 'finance.read' | 'finance.settle' | 'finance.manage' | 'reports.finance.read' | 'party.finance.read'
  | 'inventory.documents.approve';
export type PermissionOverrides = Partial<Record<Permission, boolean>>;

export interface AuthenticatedUser {
  id: string; displayName: string; role: AppRole; organizationId: string; warehouseIds: string[];
}
export interface AuthorizationDecision { allowed: boolean; reason?: string; }
export const AUTHORIZATION_MODE = 'local-only' as const;
export interface LocalAuthorizationSnapshot {
  mode: typeof AUTHORIZATION_MODE; role: AppRole; permissions: Permission[];
  trustedIdentity: false; warning: string;
}
export interface AuthorizationProvider {
  getCurrentUser(): Promise<AuthenticatedUser | null>;
  authorize(permission: Permission, resource?: { warehouseId?: string; sessionId?: string }): Promise<AuthorizationDecision>;
  signIn?(credentials: unknown): Promise<AuthenticatedUser>;
  signOut?(): Promise<void>;
}

export const PERMISSION_LABELS: Record<Permission, string> = {
  'inventory.read': 'مشاهده کالا و موجودی',
  'inventory.count': 'ثبت شمارش و اسکن بارکد',
  'inventory.edit': 'ویرایش کالا و اطلاعات موجودی',
  'inventory.import': 'ورود اطلاعات و فایل‌ها',
  'inventory.export': 'خروجی و گزارش‌گیری',
  'session.start': 'شروع دوره شمارش',
  'session.close': 'بستن دوره شمارش',
  'team.sync': 'همگام‌سازی تیمی',
  'users.manage': 'ساخت و غیرفعال‌سازی کاربران',
  'roles.assign': 'تغییر نقش و مجوز کاربران',
  'audit.read': 'مشاهده تاریخچه فعالیت‌ها',
  'audit.clear': 'پاک‌سازی تاریخچه فعالیت‌ها',
  'license.manage': 'مدیریت مجوز نرم‌افزار',
  'settings.manage': 'تغییر تنظیمات برنامه',
  'invoice.read': 'مشاهده فاکتورها و جزئیات',
  'invoice.create': 'ایجاد فاکتور و پیش‌فاکتور',
  'invoice.edit': 'اصلاح فاکتور و پیش‌نویس',
  'invoice.deleteDraft': 'حذف پیش‌نویس فاکتور',
  'invoice.post': 'قطعی‌کردن و ثبت نهایی فاکتور',
  'finance.read': 'دسترسی به اطلاعات مالی و مانده حساب‌ها',
  'finance.settle': 'تسویه فاکتور و تخصیص دریافت/پرداخت',
  'finance.manage': 'ثبت و اصلاح دریافت، پرداخت، صندوق و بانک',
  'reports.finance.read': 'مشاهده گزارش‌های مالی و سود',
  'party.finance.read': 'مشاهده مانده و گردش مالی طرف‌حساب‌ها',
  'inventory.documents.approve': 'تأیید اسناد ورود، خروج و انتقال انبار',
};

const ROLE_PERMISSIONS: Record<AppRole, ReadonlySet<Permission>> = {
  admin: new Set(Object.keys(PERMISSION_LABELS) as Permission[]),
  counter: new Set<Permission>(['inventory.read','inventory.count','inventory.export','session.start','session.close','team.sync','audit.read','invoice.read','invoice.create']),
  viewer: new Set<Permission>(['inventory.read','inventory.export','audit.read','invoice.read']),
};
let activeOverrides: PermissionOverrides = {};

export function setLocalPermissionOverrides(overrides?: PermissionOverrides | null): void {
  activeOverrides = {};
  if (!overrides || typeof overrides !== 'object') return;
  for (const [key, value] of Object.entries(overrides)) {
    if (isKnownPermission(key) && typeof value === 'boolean') activeOverrides[key] = value;
  }
}
export function roleAllows(role: AppRole, permission: Permission): boolean {
  if (role === 'admin') return true;
  if (role === 'counter' || role === 'viewer') return ROLE_PERMISSIONS[role].has(permission);
  return readCustomRoles().find(r => r.id === role)?.permissions.includes(permission) || false;
}
export function getLocalAuthorizationSnapshot(settings: Pick<AppSettings, 'role'>): LocalAuthorizationSnapshot {
  const role = currentLocalRole(settings);
  const permissions = (Object.keys(PERMISSION_LABELS) as Permission[]).filter(p =>
    role === 'admin' || (activeOverrides[p] ?? roleAllows(role, p))
  );
  return { mode: AUTHORIZATION_MODE, role, permissions, trustedIdentity: false,
    warning: 'نقش و مجوزها فقط روی همین دستگاه ذخیره می‌شوند و جایگزین احراز هویت سمت سرور نیستند.' };
}
export function authorizeLocally(settings: Pick<AppSettings, 'role'>, permission: Permission): AuthorizationDecision {
  const role = currentLocalRole(settings);
  // مدیر اصلی همیشه دسترسی کامل دارد تا برنامه قفل نشود.
  const allowed = role === 'admin' || (activeOverrides[permission] ?? roleAllows(role, permission));
  return allowed ? { allowed: true } : { allowed: false, reason: `نقش ${role} مجوز ${permission} را ندارد` };
}
/** نقش‌های معتبر برنامه. هر مقدار دیگر «ناشناخته» است. */
export const KNOWN_APP_ROLES: readonly AppRole[] = ['admin', 'counter', 'viewer'];

/**
 * نرمال‌سازی نقش:
 * - admin / counter / viewer → همان
 * - خالی/null (راه‌اندازی اولیه بدون نقش) → admin تا برنامه قفل نشود
 * - هر مقدار ناشناخته/خراب → viewer (کم‌ترین سطح دسترسی؛ نه admin)
 */
export function normalizeAppRole(role: unknown): AppRole {
  if (role === 'admin' || role === 'counter' || role === 'viewer') return role;
  if (role == null || role === '') return 'admin';
  if (typeof role === 'string' && readCustomRoles().some(r => r.id === role)) return role;
  return 'viewer';
}

export function currentLocalRole(settings: Pick<AppSettings, 'role'>): AppRole {
  return normalizeAppRole(settings.role);
}
export function isKnownPermission(value: string): value is Permission {
  return Object.prototype.hasOwnProperty.call(PERMISSION_LABELS, value);
}
