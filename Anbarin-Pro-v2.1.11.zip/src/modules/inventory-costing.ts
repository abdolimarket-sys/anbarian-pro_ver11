/** موتور بهای تمام‌شده و اتصال گردش فاکتور به موجودی */
import { idbGet, idbPut, idbPutMany } from './storage';
import type { AccountingSettings } from './accounting';

export interface CostLayer { id:string; productId:string; warehouse:string; qtyMilli:number; unitCostRial:number; /** ارزش دقیق لایه برای جلوگیری از خطای گردکردن */ valueRial?:number; date:string; sourceDocumentId:string; }
export interface CostBalance { productId:string; warehouse:string; qtyMilli:number; valueRial:number; averageUnitCostRial:number; }
export interface StockMovement { id:string; sourceDocumentId:string; productId:string; warehouse:string; type:'purchase'|'sale'; qtyMilli:number; unitCostRial:number; totalCostRial:number; beforeQtyMilli:number; afterQtyMilli:number; date:string; provisional:boolean; }
export interface InventoryCostData { schemaVersion:1; layers:CostLayer[]; balances:CostBalance[]; movements:StockMovement[]; }
const KEY='accounting_phase23_costing', BACKUP='accounting_phase23_costing_backup';
const id=(p:string)=>`${p}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`;
const safe=(n:number)=>Number.isSafeInteger(n)&&n>=0;
export const emptyInventoryCostData=():InventoryCostData=>({schemaVersion:1,layers:[],balances:[],movements:[]});
export async function loadInventoryCostData():Promise<InventoryCostData>{
  for(const key of [KEY,BACKUP])try{const x=await idbGet<InventoryCostData>(key);if(x?.schemaVersion===1&&Array.isArray(x.layers)&&Array.isArray(x.balances)&&Array.isArray(x.movements))return x;}catch(e){console.warn('costing read failed',e)}
  return emptyInventoryCostData();
}
export async function saveInventoryCostData(x:InventoryCostData):Promise<void>{if(x.schemaVersion!==1)throw new Error('ساختار بهای تمام‌شده معتبر نیست.');await idbPutMany([{key:BACKUP,value:x},{key:KEY,value:x}])}
export function seedOpeningStock(data:InventoryCostData,productId:string,warehouse:string,qtyMilli:number):void{if(!data.balances.some(x=>x.productId===productId&&x.warehouse===warehouse)&&qtyMilli>0)throw new Error('برای موجودی اول دوره، ابتدا بهای واحد موجودی را در بخش «ارزش‌گذاری موجودی اولیه» ثبت کنید.');}
export function setOpeningStockCost(data:InventoryCostData,input:{productId:string;warehouse:string;qtyMilli:number;unitCostRial:number;date:string}):InventoryCostData{if(!safe(input.qtyMilli)||input.qtyMilli<=0||!safe(input.unitCostRial)||input.unitCostRial<=0)throw new Error('تعداد و بهای واحد موجودی اولیه باید بیشتر از صفر باشد.');if(data.movements.some(m=>m.productId===input.productId&&m.warehouse===input.warehouse))throw new Error('برای این کالا گردش ثبت شده؛ ارزش‌گذاری اولیه پس از شروع گردش مجاز نیست.');if(data.balances.some(b=>b.productId===input.productId&&b.warehouse===input.warehouse))throw new Error('موجودی اولیه این کالا قبلاً ارزش‌گذاری شده است.');const value=Math.round(input.qtyMilli*input.unitCostRial/1000);setBalance(data,{productId:input.productId,warehouse:input.warehouse,qtyMilli:input.qtyMilli,valueRial:value,averageUnitCostRial:input.unitCostRial});data.layers.push({id:id('opening'),productId:input.productId,warehouse:input.warehouse,qtyMilli:input.qtyMilli,unitCostRial:input.unitCostRial,valueRial:value,date:input.date,sourceDocumentId:`opening:${input.productId}:${input.warehouse}`});return data;}
export function getCostBalance(data:InventoryCostData,productId:string,warehouse:string):CostBalance{return data.balances.find(x=>x.productId===productId&&x.warehouse===warehouse)||{productId,warehouse,qtyMilli:0,valueRial:0,averageUnitCostRial:0}}
function setBalance(data:InventoryCostData,b:CostBalance){const i=data.balances.findIndex(x=>x.productId===b.productId&&x.warehouse===b.warehouse);if(i<0)data.balances.push(b);else data.balances[i]=b}
function assertFifoLayerIntegrity(data:InventoryCostData,productId:string,warehouse:string,name='کالا'):void{
  const b=getCostBalance(data,productId,warehouse);
  const layers=data.layers.filter(l=>l.productId===productId&&l.warehouse===warehouse&&l.qtyMilli>0);
  const qty=layers.reduce((sum,l)=>sum+l.qtyMilli,0);
  const value=layers.reduce((sum,l)=>sum+(Number.isSafeInteger(l.valueRial)?l.valueRial!:Math.round(l.qtyMilli*l.unitCostRial/1000)),0);
  const expectedQty=Math.max(0,b.qtyMilli);
  const expectedValue=Math.max(0,b.valueRial);
  if(qty!==expectedQty)throw new Error(`تعداد لایه‌های FIFO کالای «${name}» با مانده دفتر بها برابر نیست؛ ثبت گردش متوقف شد.`);
  if(value!==expectedValue)throw new Error(`ارزش لایه‌های FIFO کالای «${name}» با ارزش دفتر بها برابر نیست؛ ثبت گردش متوقف شد.`);
  if(b.qtyMilli<0&&layers.length)throw new Error(`مانده منفی قدیمی کالای «${name}» دارای لایه FIFO نامعتبر است؛ ابتدا مغایرت اصلاح شود.`);
}

/**
 * خرید: ثبت لایه FIFO و به‌روزرسانی میانگین متحرک.
 * unitCostRial = بهای ثبت در موجودی (واقعی یا استاندارد).
 * actualUnitCostRial اختیاری: بهای واقعی فاکتور برای محاسبه انحراف (اگر با واحد ثبت فرق کند).
 */
export function receiveStock(data:InventoryCostData,input:{productId:string;warehouse:string;qtyMilli:number;unitCostRial:number;date:string;sourceDocumentId:string;actualUnitCostRial?:number;totalCostOverrideRial?:number;validateFifoLayers?:boolean}):{data:InventoryCostData;totalCostRial:number;inventoryValueRial:number;negativeOffsetCostRial:number;priceVarianceRial:number}{
  if(!safe(input.qtyMilli)||input.qtyMilli<=0||!safe(input.unitCostRial))throw new Error('مقدار یا بهای خرید نامعتبر است.');
  if(data.movements.some(m=>m.sourceDocumentId===input.sourceDocumentId&&m.productId===input.productId)){
    const old=data.movements.find(m=>m.sourceDocumentId===input.sourceDocumentId&&m.productId===input.productId)!;
    return {data,totalCostRial:old.totalCostRial,inventoryValueRial:old.totalCostRial,negativeOffsetCostRial:0,priceVarianceRial:0};
  }
  const calculatedTotal=Math.round(input.qtyMilli*input.unitCostRial/1000);
  const total=input.totalCostOverrideRial==null?calculatedTotal:input.totalCostOverrideRial;
  if(!safe(total)||total<=0)throw new Error('ارزش کل رسید موجودی معتبر نیست.');
  // actualUnitCostRial فقط وقتی جدا از بهای ثبت موجودی است معنا دارد (انحراف قیمت)
  const hasActual=input.actualUnitCostRial!=null && Number.isFinite(input.actualUnitCostRial) && (input.actualUnitCostRial as number)>=0;
  const actualUnit=hasActual?Math.round(input.actualUnitCostRial as number):input.unitCostRial;
  const actualTotal=Math.round(input.qtyMilli*actualUnit/1000);
  const priceVarianceRial=actualTotal-total; // مثبت = بهای واقعی بالاتر از بهای ثبت‌شده در موجودی
  const b=getCostBalance(data,input.productId,input.warehouse);
  if(input.validateFifoLayers)assertFifoLayerIntegrity(data,input.productId,input.warehouse);
  const nextQty=b.qtyMilli+input.qtyMilli;
  // رسید ابتدا کسری منفی قبلی را پوشش می‌دهد؛ فقط بخش باقی‌مانده دارایی موجودی می‌شود.
  const offsetQty=Math.min(input.qtyMilli,Math.max(0,-b.qtyMilli));const remainingQty=input.qtyMilli-offsetQty;const negativeOffsetCostRial=offsetQty>0?Math.min(total,Math.round(total*offsetQty/input.qtyMilli)):0;const inventoryValueRial=total-negativeOffsetCostRial;const nextValue=(b.qtyMilli<0?inventoryValueRial:Math.max(0,b.valueRial)+total);setBalance(data,{...b,qtyMilli:nextQty,valueRial:nextValue,averageUnitCostRial:nextQty>0?Math.round(nextValue*1000/nextQty):0});
  if(remainingQty>0)data.layers.push({id:id('layer'),productId:input.productId,warehouse:input.warehouse,qtyMilli:remainingQty,unitCostRial:input.unitCostRial,valueRial:inventoryValueRial,date:input.date,sourceDocumentId:input.sourceDocumentId});
  data.movements.push({id:id('move'),sourceDocumentId:input.sourceDocumentId,productId:input.productId,warehouse:input.warehouse,type:'purchase',qtyMilli:input.qtyMilli,unitCostRial:input.unitCostRial,totalCostRial:total,beforeQtyMilli:b.qtyMilli,afterQtyMilli:nextQty,date:input.date,provisional:false});
  return {data,totalCostRial:total,inventoryValueRial,negativeOffsetCostRial,priceVarianceRial};
}
/** فروش/خروج: فقط از موجودی دارای بهای معتبر مصرف می‌کند.
 * سیاست موجودی منفی در سطح انبار دیگر مجوز ثبت خروج با بهای صفر نیست؛
 * برای خروج بدون بهای قابل اتکا باید ابتدا رسید/ارزش‌گذاری معتبر ثبت شود.
 */
export function issueStock(data:InventoryCostData,input:{productId:string;warehouse:string;qtyMilli:number;date:string;sourceDocumentId:string;method:AccountingSettings['defaultCostingMethod'];allowNegative:boolean;productName?:string;sourceLayerDocumentId?:string}):{data:InventoryCostData;totalCostRial:number;provisional:boolean}{
  if(!safe(input.qtyMilli)||input.qtyMilli<=0)throw new Error('مقدار خروج نامعتبر است.');
  if(!input.productId?.trim()||!input.warehouse?.trim()||!input.sourceDocumentId?.trim())throw new Error('شناسه کالا، انبار و سند خروج الزامی است.');
  const existing=data.movements.find(m=>m.sourceDocumentId===input.sourceDocumentId&&m.productId===input.productId);
  if(existing){
    if(existing.type!=='sale'||existing.qtyMilli!==input.qtyMilli||existing.warehouse!==input.warehouse)throw new Error('شناسه سند خروج قبلاً برای گردش متفاوتی استفاده شده است.');
    return {data,totalCostRial:existing.totalCostRial,provisional:existing.provisional};
  }
  const b=getCostBalance(data,input.productId,input.warehouse);
  const name=(input.productName||'').trim()||'نامشخص';
  if(b.qtyMilli<input.qtyMilli){
    const have=b.qtyMilli/1000, need=input.qtyMilli/1000;
    throw new Error(`خروج کالای «${name}» بدون موجودی دارای بهای معتبر مجاز نیست. موجودی: ${have} — مقدار خروج: ${need} (انبار: ${input.warehouse})`);
  }
  if(!safe(b.valueRial)||b.valueRial<=0||!safe(b.averageUnitCostRial)||b.averageUnitCostRial<=0)throw new Error(`بهای موجودی کالای «${name}» معتبر نیست؛ ابتدا موجودی را ارزش‌گذاری کنید.`);

  let total=0;
  if(input.method==='fifo'||input.sourceLayerDocumentId){
    assertFifoLayerIntegrity(data,input.productId,input.warehouse,name);
    const allLayers=data.layers.filter(l=>l.productId===input.productId&&l.warehouse===input.warehouse&&l.qtyMilli>0);
    const layers=allLayers.filter(l=>!input.sourceLayerDocumentId||l.sourceDocumentId===input.sourceLayerDocumentId)
      .sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id));
    if(input.sourceLayerDocumentId&&!layers.length)throw new Error('لایه بهای فاکتور خرید مرجع برای برگشت یافت نشد.');
    let remaining=input.qtyMilli;
    const eligibleQty=layers.reduce((sum,l)=>sum+l.qtyMilli,0);
    if(eligibleQty<input.qtyMilli)throw new Error('موجودی باقی‌مانده از فاکتور خرید مرجع برای برگشت کافی نیست.');
    for(const layer of layers){
      if(remaining<=0)break;
      const take=Math.min(remaining,layer.qtyMilli);
      const beforeValue=Number.isSafeInteger(layer.valueRial)?layer.valueRial!:Math.round(layer.qtyMilli*layer.unitCostRial/1000);
      const afterQty=layer.qtyMilli-take;
      const consumedValue=afterQty===0?beforeValue:Math.round(beforeValue*take/layer.qtyMilli);
      const afterValue=beforeValue-consumedValue;
      total+=consumedValue;
      layer.qtyMilli=afterQty;
      layer.valueRial=afterValue;
      remaining-=take;
    }
    if(remaining!==0||total<=0)throw new Error(`بهای FIFO کافی برای خروج کالای «${name}» وجود ندارد.`);
  }else{
    total=Math.round(input.qtyMilli*b.averageUnitCostRial/1000);
    if(total<=0)throw new Error(`میانگین بهای معتبر برای خروج کالای «${name}» وجود ندارد.`);
  }
  if(total>b.valueRial)throw new Error(`بهای خروج کالای «${name}» از ارزش دفتری موجودی بیشتر است؛ خروج متوقف شد.`);
  const nextQty=b.qtyMilli-input.qtyMilli;
  const nextValue=b.valueRial-total;
  if(nextQty===0&&nextValue!==0)throw new Error(`پس از خروج کامل کالای «${name}»، مانده ارزش موجودی صفر نمی‌شود؛ مغایرت بهای موجودی را بررسی کنید.`);
  setBalance(data,{...b,qtyMilli:nextQty,valueRial:nextValue,averageUnitCostRial:nextQty>0?Math.round(nextValue*1000/nextQty):0});
  data.movements.push({id:id('move'),sourceDocumentId:input.sourceDocumentId,productId:input.productId,warehouse:input.warehouse,type:'sale',qtyMilli:input.qtyMilli,unitCostRial:Math.round(total*1000/input.qtyMilli),totalCostRial:total,beforeQtyMilli:b.qtyMilli,afterQtyMilli:nextQty,date:input.date,provisional:false});
  return {data,totalCostRial:total,provisional:false};
}

/** ——— NRV (IAS 2): بهای تمام‌شده یا خالص ارزش فروش، هرکدام کمتر ——— */

export interface NrvRow {
  productId: string;
  productName: string;
  warehouse: string;
  quantityMilli: number;
  costUnitRial: number;
  costValueRial: number;
  /** قیمت فروش واحد مبنای NRV (ریال) */
  sellingUnitRial: number;
  /** درصد هزینه فروش برآوردی از قیمت فروش (۰–۱۰۰) */
  sellingCostPercent: number;
  nrvUnitRial: number;
  nrvValueRial: number;
  /** ارزش گزارش‌شده = min(cost, NRV) */
  reportedValueRial: number;
  writeDownRial: number;
  hasSellingPrice: boolean;
}

/**
 * خالص ارزش فروش واحد = قیمت فروش − هزینه برآوردی تکمیل/فروش
 * قیمت فروش: price (فروش) و در صورت نبود consumerPrice
 */
export function estimateNrvUnitRial(
  product: { price?: number; consumerPrice?: number } | undefined,
  sellingCostPercent = 0,
): { sellingUnitRial: number; nrvUnitRial: number; hasSellingPrice: boolean } {
  const selling = Math.max(0, Math.round(Number(product?.price) || Number(product?.consumerPrice) || 0));
  if (selling <= 0) return { sellingUnitRial: 0, nrvUnitRial: 0, hasSellingPrice: false };
  const pct = Math.min(100, Math.max(0, Number(sellingCostPercent) || 0));
  const nrv = Math.max(0, Math.round(selling * (1 - pct / 100)));
  return { sellingUnitRial: selling, nrvUnitRial: nrv, hasSellingPrice: true };
}

export function buildNrvAnalysis(
  data: InventoryCostData,
  productList: Array<{ id: string; name: string; price?: number; consumerPrice?: number }>,
  opts?: { sellingCostPercent?: number },
): NrvRow[] {
  const pct = opts?.sellingCostPercent ?? 0;
  const productById = new Map(productList.map(product => [product.id, product] as const));
  const rows: NrvRow[] = [];
  for (const b of data.balances) {
    if (!b.qtyMilli || b.qtyMilli <= 0) continue;
    const p = productById.get(b.productId);
    const est = estimateNrvUnitRial(p, pct);
    const costUnit = b.qtyMilli > 0 ? Math.round((b.valueRial * 1000) / b.qtyMilli) : b.averageUnitCostRial;
    const costValue = Math.max(0, b.valueRial);
    const nrvValue = est.hasSellingPrice ? Math.round((b.qtyMilli * est.nrvUnitRial) / 1000) : costValue;
    const reported = est.hasSellingPrice ? Math.min(costValue, nrvValue) : costValue;
    const writeDown = Math.max(0, costValue - reported);
    rows.push({
      productId: b.productId,
      productName: p?.name || b.productId,
      warehouse: b.warehouse,
      quantityMilli: b.qtyMilli,
      costUnitRial: costUnit,
      costValueRial: costValue,
      sellingUnitRial: est.sellingUnitRial,
      sellingCostPercent: pct,
      nrvUnitRial: est.nrvUnitRial,
      nrvValueRial: nrvValue,
      reportedValueRial: reported,
      writeDownRial: writeDown,
      hasSellingPrice: est.hasSellingPrice,
    });
  }
  return rows.sort((a, b) => b.writeDownRial - a.writeDownRial || a.productName.localeCompare(b.productName, 'fa'));
}

/**
 * اعمال کاهش ارزش موجودی تا سطح NRV (فقط کاهش ارزش دفتر بها؛ تعداد تغییر نمی‌کند).
 * لایه‌های FIFO نیز به‌نسبت کاهش می‌یابند تا میانگین/خروج بعدی سازگار بماند.
 */
/** انحراف بهای استاندارد نسبت به خرید واقعی (از روی فاکتور خرید قطعی) */
export interface StandardCostVarianceRow {
  productId: string;
  productName: string;
  invoiceId: string;
  invoiceNumber: string;
  date: string;
  quantityMilli: number;
  standardUnitRial: number;
  actualUnitRial: number;
  standardTotalRial: number;
  actualTotalRial: number;
  varianceRial: number; // actual - standard ؛ مثبت = نامساعد
}

export function buildPurchaseStandardVariance(
  invoices: Array<{
    id: string;
    number: string;
    date: string;
    type: string;
    status: string;
    lines: Array<{
      productId?: string;
      quantityMilli: number;
      unitPriceRial: number;
      /** مبلغ ردیف بعد از تخفیف */
      totalRial?: number;
      discountRial?: number;
      allocatedLandedRial?: number;
      description?: string;
    }>;
  }>,
  productList: Array<{ id: string; name: string; standardCostRial?: number }>,
): StandardCostVarianceRow[] {
  const rows: StandardCostVarianceRow[] = [];
  const productById = new Map(productList.map(product => [product.id, product] as const));
  for (const inv of invoices) {
    if (inv.type !== 'purchase' || inv.status !== 'posted') continue;
    for (const line of inv.lines) {
      if (!line.productId || line.quantityMilli <= 0) continue;
      const p = productById.get(line.productId);
      const std = Math.round(Number(p?.standardCostRial) || 0);
      if (std <= 0) continue;
      const landedShare = Math.max(0, Math.round(Number(line.allocatedLandedRial) || 0));
      // بهای واقعی کالا = مبلغ بعد از تخفیف (totalRial)؛ در نبود آن از قیمت واحد − تخفیف محاسبه می‌شود
      const grossMerchandise = Math.round(line.quantityMilli * line.unitPriceRial / 1000);
      const discount = Math.max(0, Math.round(Number(line.discountRial) || 0));
      const netMerchandise = line.totalRial != null && Number.isFinite(Number(line.totalRial))
        ? Math.round(Number(line.totalRial))
        : Math.max(0, grossMerchandise - discount);
      // actual شامل سهم Landed است؛ برای مقایسه منصفانه همان سهم به بهای استاندارد هم اضافه می‌شود
      // تا انحراف فقط اختلاف قیمت خرید (بعد از تخفیف) با استاندارد باشد
      const actualTotal = netMerchandise + landedShare;
      const standardTotal = Math.round(line.quantityMilli * std / 1000) + landedShare;
      const actualUnit = line.quantityMilli > 0 ? Math.round(actualTotal * 1000 / line.quantityMilli) : netMerchandise;
      rows.push({
        productId: line.productId,
        productName: p?.name || line.description || line.productId,
        invoiceId: inv.id,
        invoiceNumber: inv.number,
        date: inv.date,
        quantityMilli: line.quantityMilli,
        standardUnitRial: std,
        actualUnitRial: actualUnit,
        standardTotalRial: standardTotal,
        actualTotalRial: actualTotal,
        varianceRial: actualTotal - standardTotal,
      });
    }
  }
  return rows.sort((a, b) => b.date.localeCompare(a.date) || a.productName.localeCompare(b.productName, 'fa'));
}

export function applyNrvWriteDown(
  data: InventoryCostData,
  input: { productId: string; warehouse: string; writeDownRial: number },
): InventoryCostData {
  if (!safe(input.writeDownRial) || input.writeDownRial <= 0) throw new Error('مبلغ کاهش ارزش باید بیشتر از صفر باشد.');
  const b = getCostBalance(data, input.productId, input.warehouse);
  if (b.qtyMilli <= 0) throw new Error('برای این کالا موجودی مثبت جهت کاهش ارزش وجود ندارد.');
  if (input.writeDownRial > b.valueRial) throw new Error('مبلغ کاهش ارزش نمی‌تواند از ارزش دفتری موجودی بیشتر باشد.');
  const nextValue = b.valueRial - input.writeDownRial;
  const nextAvg = b.qtyMilli > 0 ? Math.round((nextValue * 1000) / b.qtyMilli) : 0;
  // کاهش تناسبی بهای لایه‌های باقی‌مانده
  const layers = data.layers.filter(l => l.productId === input.productId && l.warehouse === input.warehouse && l.qtyMilli > 0);
  const layerValue = layers.reduce((s, l) => s + (Number.isSafeInteger(l.valueRial) ? l.valueRial! : Math.round((l.qtyMilli * l.unitCostRial) / 1000)), 0);
  if (layers.length && layerValue > 0 && nextValue >= 0) {
    const ratio = nextValue / layerValue;
    let assigned = 0;
    layers.forEach((layer, index) => {
      const oldLayerValue = Number.isSafeInteger(layer.valueRial) ? layer.valueRial! : Math.round(layer.qtyMilli * layer.unitCostRial / 1000);
      const newLayerValue = index === layers.length - 1
        ? Math.max(0, nextValue - assigned)
        : Math.max(0, Math.round(oldLayerValue * ratio));
      layer.valueRial = newLayerValue;
      layer.unitCostRial = layer.qtyMilli > 0 ? Math.max(0, Math.round(newLayerValue * 1000 / layer.qtyMilli)) : 0;
      assigned += newLayerValue;
    });
  }
  setBalance(data, { ...b, valueRial: nextValue, averageUnitCostRial: nextAvg });
  return data;
}
