import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = (p) => fs.readFileSync(new URL(p, import.meta.url), 'utf8');

test('phase 23 links invoice lines to inventory products and warehouse', () => {
  const commerce = read('../src/modules/accounting-commerce.ts');
  const ui = read('../src/modules/accounting-commerce-ui.ts');
  assert.match(commerce, /productId\?: string; warehouse\?: string/);
  assert.match(commerce, /products\.find\(p=>p\.id===line\.productId\)/);
  assert.match(commerce, /movement\.beforeQtyMilli/);
  assert.match(commerce, /movement\.afterQtyMilli/);
  assert.match(ui, /data-line-product/);
  assert.match(ui, /setOpeningStockCost/);
});

test('costing supports FIFO and moving average while blocking unvalued negative stock', () => {
  const costing = read('../src/modules/inventory-costing.ts');
  const commerce = read('../src/modules/accounting-commerce.ts');
  assert.match(costing, /input\.method==='fifo'/);
  assert.match(costing, /averageUnitCostRial/);
  assert.match(commerce, /allowNegative:false/);
  assert.match(costing, /if\(b\.qtyMilli<input\.qtyMilli\)/);
  assert.match(costing, /بدون موجودی دارای بهای معتبر مجاز نیست/);
  assert.match(costing, /assertFifoLayerIntegrity/);
  assert.match(costing, /qty!==expectedQty/);
  assert.match(costing, /value!==expectedValue/);
});

test('phase 23 posts inventory and COGS accounts and protects unvalued opening stock', () => {
  const commerce = read('../src/modules/accounting-commerce.ts');
  const costing = read('../src/modules/inventory-costing.ts');
  assert.match(commerce, /det-inventory/);
  assert.match(commerce, /det-cogs-goods/);
  assert.match(commerce, /saveInventoryCostData|commitFinancialDomains/);
  assert.match(costing, /بهای واحد موجودی/);
  assert.match(costing, /setOpeningStockCost/);
});

test('phase 23 does not rewrite the barcode scanner module', () => {
  const scanner = read('../src/modules/scanner.ts');
  assert.match(scanner, /Html5Qrcode|ZXing|barcode/i);
});


test('failed invoice financial commit restores in-memory product stock and catalog price snapshots', () => {
  const commerce = read('../src/modules/accounting-commerce.ts');
  const start = commerce.indexOf('const productSnapshots = new Map');
  const end = commerce.indexOf('// موجودی کارت کالا — مسیر ثانویه پس از موفقیت مالی', start);
  const block = commerce.slice(start, end);
  assert.ok(start >= 0 && end > start, 'invoice product snapshot and commit block must exist');
  assert.match(block, /applyCostingBalancesToProducts\(costing, ids\)/);
  assert.match(block, /applyCatalogPricesAfterPurchase\(invoice, costing, workingAccounting\)/);
  assert.match(block, /await commitFinancialDomains\(/);
  assert.match(block, /catch \(error\)/);
  for (const field of ['systemQty', 'purchasePrice', 'price']) {
    assert.ok(block.includes(`product.${field} = snapshot.${field}`), `missing rollback for ${field}`);
  }
  assert.ok(block.includes('product.stockByWarehouse = { ...snapshot.stockByWarehouse }'));
  assert.ok(block.includes('delete product.stockByWarehouse'));
});
