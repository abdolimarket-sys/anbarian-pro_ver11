import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('audit history uses a single Persian calendar and Persian digits', () => {
  const helpers = read('src/utils/helpers.ts');
  assert.match(helpers, /calendar:\s*'persian'/);
  assert.match(helpers, /numberingSystem:\s*'arabext'/);
  assert.match(helpers, /تاریخ نامعتبر/);
});

test('audit actions and details have user-friendly Persian labels without raw JSON fallback', () => {
  const audit = read('src/modules/audit-ui.ts');
  for (const label of ['ثبت شمارش کالا', 'ثبت قطعی سند حسابداری', 'ثبت انتقال وجه بین حساب‌ها', 'پاک‌سازی تاریخچه عملیات']) {
    assert.ok(audit.includes(label), `missing audit label: ${label}`);
  }
  assert.match(audit, /function readableDetailValue/);
  assert.doesNotMatch(audit, /return JSON\.stringify\(d\)/);
  assert.match(audit, /جزئیات ثبت شد/);
});

test('audit display changes do not alter audit storage schema or integrity operations', () => {
  const audit = read('src/modules/audit-ui.ts');
  const state = read('src/modules/state.ts');
  assert.match(audit, /verifyAuditIntegrity\(\)/);
  assert.match(audit, /logAudit\('audit_log_cleared'/);
  assert.match(state, /ts: new Date\(\)\.toISOString\(\)/);
  assert.match(state, /integrityHash/);
});
