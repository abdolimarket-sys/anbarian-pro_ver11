import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = (p) => fs.readFileSync(new URL(p, import.meta.url), 'utf8');
const costing = read('../src/modules/inventory-costing.ts');
const commerce = read('../src/modules/accounting-commerce.ts');
const ui = read('../src/modules/accounting-commerce-ui.ts');
const invoiceHtml = read('../src/modules/commerce-ui-invoice.ts');
const accountingUi = read('../src/modules/accounting-ui.ts');

test('costing never posts an unvalued or negative stock issue, regardless of negative-stock preference', () => {
  assert.match(costing, /if\(b\.qtyMilli<input\.qtyMilli\)/);
  assert.match(costing, /بدون موجودی دارای بهای معتبر مجاز نیست/);
  assert.match(costing, /b\.averageUnitCostRial<=0/);
  assert.match(costing, /provisional:false/);
});

test('FIFO issue requires complete quantity and value agreement between layers and balance', () => {
  assert.match(costing, /assertFifoLayerIntegrity/);
  assert.match(costing, /qty!==expectedQty/);
  assert.match(costing, /value!==expectedValue/);
  assert.match(costing, /remaining!==0\|\|total<=0/);
});

test('return invoices must reference a posted original invoice of matching type and party', () => {
  assert.match(commerce, /isReturnInvoiceType\(input\.type\) && !input\.referenceInvoiceId/);
  assert.match(commerce, /returnSource\.status !== 'posted'/);
  assert.match(commerce, /returnSource\.partyId !== invoice\.partyId/);
});

test('cumulative product returns cannot exceed original invoice quantities', () => {
  assert.match(commerce, /alreadyReturned/);
  assert.match(commerce, /used\.qty \+ request\.qty > source\.qty/);
  assert.match(commerce, /used\.value \+ request\.value > source\.value/);
});

test('sales returns use the original sale movement cost and purchase returns consume the original purchase layer', () => {
  assert.match(commerce, /sourceMovement\?\.unitCostRial/);
  assert.match(commerce, /sourceLayerDocumentId:returnSource\.id/);
  assert.match(costing, /input\.sourceLayerDocumentId/);
});

test('return reference is selectable and persisted from the invoice form', () => {
  assert.match(ui, /returnReferenceOptionsHtml/);
  assert.match(ui, /#invoiceReferenceInvoice/);
  assert.match(ui, /فاکتور مرجع برگشت/);
  assert.match(invoiceHtml, /p\.returnReferenceOptionsHtml/);
});

test('purchase line discounts reduce the inventory cost base and are not posted as a second contra entry', () => {
  assert.match(commerce, /invoice\.type === 'purchase' \? netUnit \+ landedPerUnit/);
  assert.match(commerce, /return sum \+ line\.totalRial \+ allocated/);
  assert.doesNotMatch(commerce, /stockDiscount/);
  assert.doesNotMatch(commerce, /lines\.push\(journalLine\('det-purchase-discounts'/);
});

test('costing method cannot be switched after inventory movements exist', () => {
  assert.match(accountingUi, /requestedCostingMethod!==data\.settings\.defaultCostingMethod/);
  assert.match(accountingUi, /costing\.movements\.length>0/);
  assert.match(accountingUi, /روش بهای تمام‌شده پس از ثبت اولین گردش انبار قابل تغییر نیست/);
});

test('legacy negative-stock preference is not exposed as an active permission in accounting settings', () => {
  assert.match(accountingUi, /accAllowNegativeStock" disabled/);
  assert.match(accountingUi, /خروج فقط تا سقف موجودی دارای بهای معتبر مجاز است/);
  assert.doesNotMatch(accountingUi, /data\.settings\.allowNegativeStock=/);
});

test('purchase-return journal balances refund value against the actual inventory cost removed', () => {
  assert.match(commerce, /invoice\.type === 'return-purchase'/);
  assert.match(commerce, /purchasePriceVariance = invoice\.netRial - inventoryValue - nonStockReturn/);
  assert.match(commerce, /invoice\.type==='return-purchase'\)\?\['det-purchase-price-variance'\]/);
});
