import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const reports = readFileSync(new URL('../src/modules/reports.ts', import.meta.url), 'utf8');

function exportFunction() {
  const start = reports.indexOf('export function exportCountedProductsExcel(): void {');
  assert.notEqual(start, -1, 'counted products export function must exist');
  const end = reports.indexOf('\nexport function exportAccountingDoc', start);
  assert.notEqual(end, -1, 'counted products export function boundary must exist');
  return reports.slice(start, end);
}

test('counted-products export uses the warehouse visibility policy, not the legacy exact-name filter', () => {
  const body = exportFunction();
  assert.match(reports, /import \{ productVisibleInWarehouse \} from '\.\/warehouse-stock';/);
  assert.match(body, /products\.filter\(\(p\) => productVisibleInWarehouse\(p, selectedWarehouse\)\)/);
  assert.doesNotMatch(body, /activeList\(\)/);
});

test('counted-products export includes valid zero counts and either phase in double-count mode', () => {
  const body = exportFunction();
  assert.match(body, /doubleCount \? p\.countedQty != null \|\| p\.countedQty2 != null : p\.countedQty != null/);
  assert.match(body, /p\.countedQty2 != null \? p\.countedQty2 : p\.countedQty/);
});

test('counted-products export remains read-only and preserves workbook generation and audit', () => {
  const body = exportFunction();
  assert.match(body, /buildOfflineXlsx\(/);
  assert.match(body, /downloadFile\(/);
  assert.match(body, /logAudit\('export_counted_products_xlsx'/);
  assert.doesNotMatch(body, /\.countedQty\s*=|\.countedQty2\s*=|\.systemQty\s*=/);
});
