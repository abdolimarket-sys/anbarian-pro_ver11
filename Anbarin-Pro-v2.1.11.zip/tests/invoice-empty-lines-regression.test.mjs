import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const ui = fs.readFileSync(new URL('../src/modules/accounting-commerce-ui.ts', import.meta.url), 'utf8');
const template = fs.readFileSync(new URL('../src/modules/commerce-ui-invoice.ts', import.meta.url), 'utf8');

test('invoice item sheet allows zero rows and does not auto-create a phantom blank row', () => {
  const openSheet = ui.slice(ui.indexOf('function openInvoiceItemsSheet'), ui.indexOf('/** محتوای HTML خالص'));
  assert.doesNotMatch(openSheet, /if\s*\(!mount\.querySelector\('#commerceInvoiceLines \.commerce-line'\)\)\s*\{\s*addInvoiceLine\(\);/);
  assert.match(ui, /row\.remove\(\);\s*updateInvoiceLineNumbers\(host\);\s*updateInvoiceTotals\(\)/);
  assert.doesNotMatch(ui, /فاکتور باید حداقل یک ردیف داشته باشد/);
});

test('invoice item summary counts meaningful lines, not blank row containers', () => {
  assert.match(ui, /function countMeaningfulInvoiceLines\(host:ParentNode\):number/);
  assert.match(ui, /return !!productId \|\| !!description;/);
  assert.match(ui, /countMeaningfulInvoiceLines\(linesHost\)/);
});

test('new invoice form does not inject a blank item row automatically; manual add remains available', () => {
  assert.match(template, /id="invoiceAddLine"/);
  assert.doesNotMatch(ui, /if\(activeCommerceSection==='sale'\|\|activeCommerceSection==='purchase'\)\{\s*addInvoiceLine\(\);/);
  assert.doesNotMatch(ui, /if \(activeCommerceSection === 'sale' \|\| activeCommerceSection === 'purchase'\) \{\s*addInvoiceLine\(\);/);
});
