import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const reports = fs.readFileSync(new URL('../src/modules/accounting-reports.ts', import.meta.url), 'utf8');
const costing = fs.readFileSync(new URL('../src/modules/inventory-costing.ts', import.meta.url), 'utf8');
const commerceUi = fs.readFileSync(new URL('../src/modules/accounting-commerce-ui.ts', import.meta.url), 'utf8');
const inventoryUi = fs.readFileSync(new URL('../src/modules/commerce-ui-inventory.ts', import.meta.url), 'utf8');

test('trial balance and opening balance use indexed account lookup / one pass', () => {
  const trial = reports.slice(reports.indexOf('export function buildTrialBalance('), reports.indexOf('/** مانده اول دوره'));
  assert.match(trial, /new Map\(data\.accounts\.map/);
  assert.doesNotMatch(trial, /data\.accounts\.find\(/);
  const opening = reports.slice(reports.indexOf('export function buildAccountOpeningBalance('), reports.indexOf('/**\n * صورت سود'));
  assert.doesNotMatch(opening, /postedBefore\(/);
  assert.match(opening, /for \(const entry of data\.journalEntries\)/);
});

test('inventory valuation and NRV build product indexes instead of nested find scans', () => {
  const nrv = costing.slice(costing.indexOf('export function buildNrvAnalysis('), costing.indexOf('/**\n * اعمال کاهش ارزش'));
  assert.match(nrv, /new Map\(productList\.map/);
  assert.doesNotMatch(nrv, /productList\.find\(/);
  const valuation = reports.slice(reports.indexOf('export function buildInventoryValuation('), reports.indexOf('/** اسناد قطعی قبل'));
  assert.match(valuation, /new Map\(products\.map/);
  assert.doesNotMatch(valuation, /products\.find\(/);
});

test('pending opening stock valuation indexes existing balances and movements', () => {
  const fn = commerceUi.slice(commerceUi.indexOf('async function listPendingOpeningValuation'), commerceUi.indexOf('async function openingStockPanel'));
  assert.match(fn, /const valuedKeys = new Set/);
  assert.match(fn, /const movedKeys = new Set/);
  assert.doesNotMatch(fn, /costing\.(balances|movements)\.some/);
});

test('independent inventory panels load concurrently while retaining per-panel error isolation', () => {
  assert.match(inventoryUi, /Promise\.all\(panels\.map/);
  assert.match(inventoryUi, /catch \(e\)/);
});
