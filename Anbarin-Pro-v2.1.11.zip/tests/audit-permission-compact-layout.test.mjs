import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = (path) => readFile(new URL(path, import.meta.url), 'utf8');

test('only audit history permission cards use the compact layout in user and role editors', async () => {
  const authUi = await read('../src/modules/local-auth.ts');
  const css = await read('../src/styles/main.css');
  assert.match(authUi, /key\.startsWith\('audit\.'\) \? ' local-permission-option-compact'/);
  assert.equal((authUi.match(/local-permission-option-compact/g) || []).length, 2);
  assert.match(css, /\.local-permission-option-compact\s*\{/);
  assert.match(css, /\.local-permission-option-compact \.local-permission-check\s*\{/);
  assert.match(css, /@media\(max-width:480px\)\s*\{\s*\.local-permission-option-compact/);
  assert.match(css, /\.local-permission-option\s*\{[\s\S]*?min-height:44px/);
});
