import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const commerce = fs.readFileSync(new URL('../src/modules/accounting-commerce.ts', import.meta.url), 'utf8');
const api = fs.readFileSync(new URL('../src/modules/commerce-api.ts', import.meta.url), 'utf8');
const ui = fs.readFileSync(new URL('../src/modules/accounting-commerce-ui.ts', import.meta.url), 'utf8');
const template = fs.readFileSync(new URL('../src/modules/commerce-ui-invoice.ts', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles/main.css', import.meta.url), 'utf8');

test('invoice form always exposes a safe cancel action for unsaved work', () => {
  assert.match(template, /id="invoiceCancelEdit"[^>]*>انصراف/);
  assert.match(ui, /setCoreClickHandler\('invoiceCancelEdit', \(\) => cancelInvoiceEdit\(\)\)/);
  assert.match(ui, /function cancelInvoiceEdit\(\):void \{editingInvoiceId=null;render\(\)\}/);
});

test('draft deletion is domain-guarded and never deletes posted or financially-linked invoices', () => {
  const start = commerce.indexOf('export function deleteDraftInvoice(');
  const end = commerce.indexOf('\n/**', start + 10);
  const body = commerce.slice(start, end);
  assert.ok(start >= 0 && end > start);
  assert.match(body, /existing\.status !== 'draft'/);
  assert.match(body, /existing\.journalEntryId/);
  assert.match(body, /tx\.allocations/);
  assert.match(body, /accounting_invoice_draft_deleted/);
  assert.match(api, /deleteDraftInvoice/);
});

test('only draft invoice rows expose confirmed delete action', () => {
  assert.match(ui, /data-delete-invoice="\$\{i\.id\}"/);
  assert.match(ui, /confirmAction\(`پیش‌نویس/);
  assert.match(ui, /deleteDraftInvoice\(id, commerce\)/);
  assert.match(ui, /if \(!invoice \|\| invoice\.status !== 'draft'\)/);
});

test('posted invoice settlement action uses compact label and keeps amount in tooltip', () => {
  assert.match(ui, /تسویه مانده/);
  assert.match(ui, /title="مانده قابل تسویه:/);
  assert.match(ui, /aria-label="تسویه مانده؛/);
  assert.doesNotMatch(ui, /تسویه مانده \(\$\{money\(outstanding\)\}\)/);
});
