import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = (path) => readFile(new URL(path, import.meta.url), 'utf8');

test('custom roles are persisted, validated, and resolved without weakening the admin baseline', async () => {
  const auth = await read('../src/modules/authorization.ts');
  assert.match(auth, /anbarin_custom_roles_v1/);
  assert.match(auth, /export function readCustomRoles/);
  assert.match(auth, /export function writeCustomRoles/);
  assert.match(auth, /role === 'admin'\) return true/);
  assert.match(auth, /readCustomRoles\(\)\.find\(r => r\.id === role\)/);
  assert.match(auth, /return 'viewer'/);
});

test('finance and invoice permissions are explicit and enforced at mutation entry points', async () => {
  const auth = await read('../src/modules/authorization.ts');
  const ui = await read('../src/modules/accounting-commerce-ui.ts');
  const count = await read('../src/modules/count.ts');
  const docs = await read('../src/modules/inventory-documents.ts');
  const sync = await read('../src/modules/team-sync.ts');
  for (const key of ['invoice.edit', 'invoice.deleteDraft', 'invoice.post', 'finance.read', 'finance.settle', 'finance.manage', 'reports.finance.read']) {
    assert.ok(auth.includes(`'${key}'`), `missing ${key}`);
  }
  assert.match(ui, /guardPermission\('invoice\.deleteDraft'/);
  assert.match(ui, /guardPermission\('invoice\.edit'/);
  assert.match(ui, /guardPermission\('finance\.settle'/);
  assert.match(ui, /guardPermission\('finance\.manage'/);
  assert.match(count, /authorizeLocally\(settings, 'inventory\.count'\)/);
  assert.match(docs, /guardPermission\('inventory\.documents\.approve'/);
  assert.match(sync, /authorizeLocally\(settings, 'team\.sync'\)/);
});

test('custom role definitions are included in full backup, restore and rollback metadata', async () => {
  const backup = await read('../src/modules/device-auto-backup.ts');
  const identity = await read('../src/modules/restore-identity-metadata.ts');
  assert.match(backup, /customRoles/);
  assert.match(backup, /anbarin_custom_roles_v1/);
  assert.match(backup, /roles: string \| null/);
  assert.match(identity, /customRoles\?: unknown/);
  assert.match(identity, /anbarin_custom_roles_v1/);
});
