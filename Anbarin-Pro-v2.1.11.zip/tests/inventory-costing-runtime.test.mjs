import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
const require = createRequire(import.meta.url);
let ts;
try { ts = require('typescript'); } catch { ts = require(path.join(execFileSync('npm', ['root', '-g'], { encoding: 'utf8' }).trim(), 'typescript')); }

const source = fs.readFileSync(new URL('../src/modules/inventory-costing.ts', import.meta.url), 'utf8');
const js = ts.transpile(source, { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 });
const module = { exports: {} };
const fakeRequire = () => ({ idbGet: async () => null, idbPut: async () => {}, idbPutMany: async () => {} });
vm.runInNewContext(`(function(exports, require, module) { ${js}\n})(module.exports, require, module);`, { module, require: fakeRequire });
const costing = module.exports;
const fresh = () => costing.emptyInventoryCostData();
const settings = { defaultCostingMethod: 'fifo' };
const input = (overrides = {}) => ({ productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 1000, date: '1405/01/01', sourceDocumentId: 'sale-1', method: 'fifo', allowNegative: false, productName: 'کالای آزمایشی', ...overrides });

test('FIFO consumes oldest valued layers and keeps exact balance value', () => {
  const data = fresh();
  costing.setOpeningStockCost(data, { productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 5000, unitCostRial: 100, date: '1405/01/01' });
  costing.receiveStock(data, { productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 5000, unitCostRial: 200, date: '1405/01/02', sourceDocumentId: 'purchase-2' });
  const result = costing.issueStock(data, input({ qtyMilli: 6000 }));
  assert.equal(result.totalCostRial, 700);
  assert.equal(data.balances[0].qtyMilli, 4000);
  assert.equal(data.balances[0].valueRial, 800);
  assert.equal(data.layers.reduce((s, l) => s + l.qtyMilli, 0), 4000);
  assert.equal(data.layers.reduce((s, l) => s + l.valueRial, 0), 800);
});

test('moving average calculates weighted cost and leaves a correct remaining balance', () => {
  const data = fresh();
  costing.setOpeningStockCost(data, { productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 5000, unitCostRial: 100, date: '1405/01/01' });
  costing.receiveStock(data, { productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 5000, unitCostRial: 200, date: '1405/01/02', sourceDocumentId: 'purchase-2' });
  const result = costing.issueStock(data, input({ method: 'moving-average', qtyMilli: 4000 }));
  assert.equal(result.totalCostRial, 600);
  assert.equal(data.balances[0].qtyMilli, 6000);
  assert.equal(data.balances[0].valueRial, 900);
  assert.equal(data.balances[0].averageUnitCostRial, 150);
});

test('negative stock is rejected even when legacy allowNegative is true', () => {
  const data = fresh();
  assert.throws(() => costing.issueStock(data, input({ allowNegative: true })), /بدون موجودی دارای بهای معتبر مجاز نیست/);
});

test('FIFO refuses quantity or value divergence between layers and the costing balance', () => {
  const data = fresh();
  costing.setOpeningStockCost(data, { productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 2000, unitCostRial: 100, date: '1405/01/01' });
  data.layers[0].qtyMilli = 1000;
  assert.throws(() => costing.issueStock(data, input()), /تعداد لایه‌های FIFO.*برابر نیست/);
  data.layers[0].qtyMilli = 2000;
  data.layers[0].valueRial = 100;
  assert.throws(() => costing.issueStock(data, input()), /ارزش لایه‌های FIFO.*برابر نیست/);
});

test('purchase return consumes only remaining layer quantity from its referenced purchase', () => {
  const data = fresh();
  costing.receiveStock(data, { productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 3000, unitCostRial: 250, date: '1405/01/01', sourceDocumentId: 'purchase-original' });
  costing.receiveStock(data, { productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 2000, unitCostRial: 300, date: '1405/01/02', sourceDocumentId: 'purchase-second' });
  const result = costing.issueStock(data, input({ qtyMilli: 1000, sourceDocumentId: 'return-purchase-1', sourceLayerDocumentId: 'purchase-original' }));
  assert.equal(result.totalCostRial, 250);
  assert.equal(data.balances[0].qtyMilli, 4000);
  assert.equal(data.balances[0].valueRial, 1100);
  assert.throws(() => costing.issueStock(data, input({ qtyMilli: 3000, sourceDocumentId: 'return-purchase-2', sourceLayerDocumentId: 'purchase-original' })), /موجودی باقی‌مانده از فاکتور خرید مرجع/);
});

test('sales return can restore the exact original cost despite per-unit rounding', () => {
  const data = fresh();
  const result = costing.receiveStock(data, { productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 3000, unitCostRial: 333, totalCostOverrideRial: 1000, date: '1405/01/01', sourceDocumentId: 'return-sale-1' });
  assert.equal(result.totalCostRial, 1000);
  assert.equal(data.balances[0].valueRial, 1000);
  assert.equal(data.layers[0].valueRial, 1000);
});

test('FIFO receipt also refuses to extend an already divergent layer ledger', () => {
  const data = fresh();
  costing.setOpeningStockCost(data, { productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 2000, unitCostRial: 100, date: '1405/01/01' });
  data.layers[0].qtyMilli = 1000;
  assert.throws(() => costing.receiveStock(data, { productId: 'p1', warehouse: 'انبار اصلی', qtyMilli: 1000, unitCostRial: 100, date: '1405/01/02', sourceDocumentId: 'purchase-2', validateFifoLayers: true }), /تعداد لایه‌های FIFO.*برابر نیست/);
});
