package com.anbarian.app;

import android.provider.Settings;
import android.content.SharedPreferences;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Device-local trial anchor stored outside WebView/localStorage.
 * It survives WebView data clearing, but Android app-data clearing/uninstall may remove it.
 * Strong reinstall-proof trial issuance requires a server-signed device-bound token.
 */
@CapacitorPlugin(name = "TrialGuard")
public class TrialGuardPlugin extends Plugin {
    private static final String PREFS = "anbarin_trial_guard_v1";
    private static final String FIRST_AT = "first_at";
    private static final String LAST_SEEN = "last_seen";
    private static final String CLOCK_TAMPER = "clock_tamper";
    private static final String DEVICE_FINGERPRINT = "device_fingerprint";
    private static final long ROLLBACK_TOLERANCE_MS = 60L * 60L * 1000L;

    private String deviceFingerprint() throws Exception {
        String androidId = Settings.Secure.getString(getContext().getContentResolver(), Settings.Secure.ANDROID_ID);
        if (androidId == null || androidId.trim().isEmpty()) throw new IllegalStateException("device_identity_unavailable");
        String material = getContext().getPackageName() + ":anbarin-trial:" + androidId;
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(material.getBytes(StandardCharsets.UTF_8));
        StringBuilder out = new StringBuilder();
        for (byte b : digest) out.append(String.format(java.util.Locale.ROOT, "%02x", b));
        return out.toString();
    }

    private long parseIso(String value) {
        if (value == null || value.trim().isEmpty()) return 0L;
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.ROOT);
            format.setTimeZone(TimeZone.getTimeZone("UTC"));
            ParsePosition position = new ParsePosition(0);
            Date parsed = format.parse(value, position);
            if (parsed != null && position.getIndex() == value.length()) return parsed.getTime();
            // Accept legacy ISO strings that omit milliseconds.
            SimpleDateFormat legacy = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.ROOT);
            legacy.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date old = legacy.parse(value, new ParsePosition(0));
            return old == null ? 0L : old.getTime();
        } catch (Exception ignored) { return 0L; }
    }

    private String iso(long value) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.ROOT);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return format.format(new Date(value));
    }

    @PluginMethod
    public synchronized void getOrCreateState(PluginCall call) {
        try {
            SharedPreferences prefs = getContext().getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE);
            String fingerprint = deviceFingerprint();
            String storedFingerprint = prefs.getString(DEVICE_FINGERPRINT, null);
            long now = System.currentTimeMillis();
            long storedFirst = prefs.getLong(FIRST_AT, 0L);
            long storedLast = prefs.getLong(LAST_SEEN, 0L);
            boolean tamper = prefs.getBoolean(CLOCK_TAMPER, false);

            boolean identityMismatch = storedFingerprint != null && !storedFingerprint.equals(fingerprint);
            if (identityMismatch || (storedFingerprint != null && storedFirst <= 0L)) tamper = true;

            long legacyFirst = parseIso(call.getString("legacyFirstAt"));
            long legacyLast = parseIso(call.getString("legacyLastSeenAt"));
            if (storedFirst <= 0L) {
                // Migration preserves an existing user's original trial start date.
                storedFirst = legacyFirst > 0L && legacyFirst <= now + ROLLBACK_TOLERANCE_MS ? legacyFirst : now;
                if (call.getBoolean("legacyClockTamper", false)) tamper = true;
                if (legacyLast > 0L) storedLast = Math.max(storedLast, legacyLast);
            } else if (legacyFirst > 0L && legacyFirst < storedFirst) {
                // Never shorten a previously recorded trial because an old mirror is older.
                storedFirst = legacyFirst;
            }

            if (storedLast > 0L && now < storedLast - ROLLBACK_TOLERANCE_MS) tamper = true;
            else if (tamper && storedLast > 0L && now >= storedLast && !identityMismatch) tamper = false;

            long nextLast = Math.max(now, storedLast);
            boolean committed = prefs.edit()
                .putLong(FIRST_AT, storedFirst)
                .putLong(LAST_SEEN, nextLast)
                .putBoolean(CLOCK_TAMPER, tamper)
                .putString(DEVICE_FINGERPRINT, storedFingerprint == null ? fingerprint : storedFingerprint)
                .commit();
            if (!committed) throw new IllegalStateException("trial_state_persist_failed");

            JSObject result = new JSObject();
            result.put("firstAt", iso(storedFirst));
            result.put("lastSeenAt", iso(nextLast));
            result.put("clockTamper", tamper);
            result.put("deviceFingerprint", fingerprint);
            call.resolve(result);
        } catch (Exception error) {
            call.reject("امکان ثبت امن وضعیت دوره آزمایشی وجود ندارد.", error);
        }
    }
}
