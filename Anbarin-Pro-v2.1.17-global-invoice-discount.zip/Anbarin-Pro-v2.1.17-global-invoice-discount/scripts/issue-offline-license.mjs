#!/usr/bin/env node
/** Offline ANBARIN-LICENSE issuer. Private key must remain outside the repository and APK. */
import { readFile, writeFile } from 'node:fs/promises';
import { createSign, createPublicKey, createPrivateKey, randomUUID } from 'node:crypto';
import { resolve } from 'node:path';

const [inputPath, outputPath] = process.argv.slice(2);
if (!inputPath || !outputPath) {
  console.error('Usage: node scripts/issue-offline-license.mjs <customer.json> <output.anblic>');
  process.exit(2);
}
const privateKeyPath = process.env.ANBARIN_LICENSE_PRIVATE_KEY_FILE;
if (!privateKeyPath) throw new Error('ANBARIN_LICENSE_PRIVATE_KEY_FILE must point to the issuer private PEM outside the repository.');
const privateKeyPem = await readFile(resolve(privateKeyPath), 'utf8');
const passphrase = process.env.ANBARIN_LICENSE_PRIVATE_KEY_PASSPHRASE;
const privateKey = createPrivateKey(passphrase ? { key: privateKeyPem, passphrase } : privateKeyPem);
const registry = JSON.parse(await readFile(resolve('src/license/issuer-public-keys.json'), 'utf8'));
const keyId = String(process.env.ANBARIN_LICENSE_KEY_ID || registry.activeKeyId);
const publicKeyPath = process.env.ANBARIN_LICENSE_PUBLIC_KEY_FILE;
const configuredPublicKey = publicKeyPath
  ? await readFile(resolve(publicKeyPath), 'utf8')
  : registry.keys[keyId];
if (!configuredPublicKey) throw new Error(`Unknown issuer key id: ${keyId}`);
const derivedPublicKey = createPublicKey(privateKey).export({ type: 'spki', format: 'pem' }).toString().replace(/\s/g, '');
const configuredPublicKeyNormalized = createPublicKey(configuredPublicKey).export({ type: 'spki', format: 'pem' }).toString().replace(/\s/g, '');
if (derivedPublicKey !== configuredPublicKeyNormalized) throw new Error('Issuer private key does not match the selected public key.');
const input = JSON.parse(await readFile(resolve(inputPath), 'utf8'));
const entitlementCatalog = JSON.parse(await readFile(resolve('license-entitlements.json'), 'utf8'));
const registeredIds = Object.keys(entitlementCatalog);
const allowedFeatures = new Set(registeredIds.filter((id) => id.startsWith('feature.')));
const allowedModules = new Set(registeredIds.filter((id) => id.startsWith('module.')).map((id) => id.slice('module.'.length)));
const modules = [...new Set((input.modules || []).map(String))];
const features = [...new Set((input.features || []).map(String))];
const licenseTerm = input.licenseTerm === 'perpetual' || input.perpetual === true ? 'perpetual' : 'fixed';
if (!String(input.customerName || '').trim() || !String(input.deviceId || '').trim()) throw new Error('customerName and deviceId are required.');
if (licenseTerm === 'fixed' && !/^\d{4}-\d{2}-\d{2}$/.test(input.validUntil || '')) throw new Error('validUntil (YYYY-MM-DD) is required for fixed-term licenses.');
if (modules.some((id) => !allowedModules.has(id))) throw new Error('Unknown module id.');
if (features.some((id) => !allowedFeatures.has(id))) throw new Error('Unknown feature id.');
const validUntil = licenseTerm === 'perpetual' ? null : new Date(`${input.validUntil}T23:59:59.000Z`);
if (licenseTerm === 'fixed' && (!Number.isFinite(validUntil.getTime()) || validUntil.getTime() < Date.now())) throw new Error('validUntil must be a valid future date.');
if (!modules.length && !features.length) throw new Error('At least one module or feature must be licensed.');
const payload = {
  schemaVersion: 1,
  applicationId: 'com.anbarian.app',
  licenseId: String(input.licenseId || `ANB-${randomUUID()}`),
  customerName: String(input.customerName).trim(),
  ...(input.customerReference ? { customerReference: String(input.customerReference).trim() } : {}),
  plan: String(input.plan || 'custom'),
  ...(modules.length ? { modules } : {}),
  ...(features.length ? { features } : {}),
  issuedAt: new Date().toISOString(),
  licenseTerm,
  validUntil: licenseTerm === 'perpetual' ? null : input.validUntil,
  deviceId: String(input.deviceId).trim(),
  maxDevices: 1,
  status: 'active',
  transferRequiresIssuerApproval: true,
  ...(input.internalNote ? { internalNote: String(input.internalNote).slice(0, 500) } : {}),
};
const payloadBytes = Buffer.from(JSON.stringify(payload), 'utf8');
const signer = createSign('RSA-SHA256');
signer.update(payloadBytes); signer.end();
const signature = signer.sign(privateKey).toString('base64url');
const envelope = { format: 'ANBARIN-LICENSE', algorithm: 'RS256', keyId, payload: payloadBytes.toString('base64url'), signature };
await writeFile(resolve(outputPath), `${JSON.stringify(envelope, null, 2)}\n`, { mode: 0o600 });
console.log(`Issued ${payload.licenseId} for ${payload.customerName}; key=${keyId}; device=${payload.deviceId}; modules=${modules.join(',') || '-'}; features=${features.join(',') || '-'}; term=${licenseTerm}; validUntil=${payload.validUntil ?? 'perpetual'}`);
