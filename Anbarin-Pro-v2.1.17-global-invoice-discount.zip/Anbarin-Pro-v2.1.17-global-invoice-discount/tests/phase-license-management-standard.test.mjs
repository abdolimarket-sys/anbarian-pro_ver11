import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { generateKeyPairSync, createVerify } from 'node:crypto';

const root = process.cwd();

test('license management dashboard is read-only and driven by the central registry', () => {
  const ui = readFileSync(join(root, 'src/modules/license-management-ui.ts'), 'utf8');
  const shell = readFileSync(join(root, 'src/bootstrap/app-shell.ts'), 'utf8');
  const license = readFileSync(join(root, 'src/modules/license.ts'), 'utf8');
  assert.match(ui, /ENTITLEMENT_REGISTRY/);
  assert.match(ui, /getActiveEntitlements/);
  assert.match(shell, /licenseEntitlementDashboard/);
  assert.match(license, /renderLicenseManagementUI/);
  assert.doesNotMatch(ui, /saveStoredLicense|activateOfflineLicenseFile|deactivateOfflineLicense/);
});

test('offline issuer signs a one-device entitlement file without embedding private key', () => {
  const dir = mkdtempSync(join(tmpdir(), 'anbarin-license-issuer-'));
  try {
    const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
    const keyPath = join(dir, 'issuer-private.pem');
    const publicPath = join(dir, 'issuer-public.pem');
    const inputPath = join(dir, 'customer.json');
    const outputPath = join(dir, 'customer.anblic');
    writeFileSync(keyPath, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
    writeFileSync(publicPath, publicKey.export({ type: 'spki', format: 'pem' }));
    writeFileSync(inputPath, JSON.stringify({
      customerName: 'آزمایش مشتری', deviceId: 'DEVICE-TEST-001', validUntil: '2099-12-31',
      modules: ['count', 'accounting'], features: ['feature.taxpayer', 'feature.taxpayer_purchase_match'],
    }));
    const result = spawnSync(process.execPath, [join(root, 'scripts/issue-offline-license.mjs'), inputPath, outputPath], {
      cwd: root, encoding: 'utf8', env: { ...process.env, ANBARIN_LICENSE_PRIVATE_KEY_FILE: keyPath, ANBARIN_LICENSE_PUBLIC_KEY_FILE: publicPath },
    });
    assert.equal(result.status, 0, result.stderr);
    const envelope = JSON.parse(readFileSync(outputPath, 'utf8'));
    assert.equal(envelope.format, 'ANBARIN-LICENSE');
    assert.equal(envelope.algorithm, 'RS256');
    const payloadBytes = Buffer.from(envelope.payload, 'base64url');
    const verifier = createVerify('RSA-SHA256');
    verifier.update(payloadBytes); verifier.end();
    assert.equal(verifier.verify(publicKey, Buffer.from(envelope.signature, 'base64url')), true);
    const payload = JSON.parse(payloadBytes.toString('utf8'));
    assert.equal(payload.maxDevices, 1);
    assert.equal(payload.transferRequiresIssuerApproval, true);
    assert.deepEqual(payload.features, ['feature.taxpayer', 'feature.taxpayer_purchase_match']);
    assert.equal(payload.deviceId, 'DEVICE-TEST-001');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('offline issuer rejects unknown entitlement identifiers', () => {
  const dir = mkdtempSync(join(tmpdir(), 'anbarin-license-invalid-'));
  try {
    const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
    const keyPath = join(dir, 'issuer-private.pem');
    const publicPath = join(dir, 'issuer-public.pem');
    const inputPath = join(dir, 'customer.json');
    const outputPath = join(dir, 'customer.anblic');
    writeFileSync(keyPath, privateKey.export({ type: 'pkcs8', format: 'pem' }));
    writeFileSync(publicPath, publicKey.export({ type: 'spki', format: 'pem' }));
    writeFileSync(inputPath, JSON.stringify({ customerName: 'X', deviceId: 'D', validUntil: '2099-12-31', features: ['feature.not_registered'] }));
    const result = spawnSync(process.execPath, [join(root, 'scripts/issue-offline-license.mjs'), inputPath, outputPath], {
      cwd: root, encoding: 'utf8', env: { ...process.env, ANBARIN_LICENSE_PRIVATE_KEY_FILE: keyPath, ANBARIN_LICENSE_PUBLIC_KEY_FILE: publicPath },
    });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /Unknown feature id/);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('issuer key ring preserves the legacy verifier key and selects a versioned active key', () => {
  const ring = JSON.parse(readFileSync(join(root, 'src/license/issuer-public-keys.json'), 'utf8'));
  assert.equal(ring.activeKeyId, 'anbarin-issuer-v2');
  assert.ok(ring.keys['anbarin-issuer-v1'].includes('BEGIN PUBLIC KEY'));
  assert.ok(ring.keys['anbarin-issuer-v2'].includes('BEGIN PUBLIC KEY'));
  const verifier = readFileSync(join(root, 'src/modules/offline-license.ts'), 'utf8');
  assert.match(verifier, /configuredPublicKey\(envelope\.keyId\)/);
  assert.match(verifier, /شناسه کلید صادرکننده/);
});

test('offline issuer creates a perpetual one-device license with no artificial expiry date', () => {
  const dir = mkdtempSync(join(tmpdir(), 'anbarin-license-perpetual-'));
  try {
    const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
    const keyPath = join(dir, 'issuer-private.pem');
    const publicPath = join(dir, 'issuer-public.pem');
    const inputPath = join(dir, 'customer.json');
    const outputPath = join(dir, 'customer.anblic');
    writeFileSync(keyPath, privateKey.export({ type: 'pkcs8', format: 'pem' }));
    writeFileSync(publicPath, publicKey.export({ type: 'spki', format: 'pem' }));
    writeFileSync(inputPath, JSON.stringify({ customerName: 'مشتری دائمی', deviceId: 'DEVICE-PERP-001', licenseTerm: 'perpetual', modules: ['count'] }));
    const result = spawnSync(process.execPath, [join(root, 'scripts/issue-offline-license.mjs'), inputPath, outputPath], {
      cwd: root, encoding: 'utf8', env: { ...process.env, ANBARIN_LICENSE_PRIVATE_KEY_FILE: keyPath, ANBARIN_LICENSE_PUBLIC_KEY_FILE: publicPath, ANBARIN_LICENSE_KEY_ID: 'test-perpetual-key' },
    });
    assert.equal(result.status, 0, result.stderr);
    const envelope = JSON.parse(readFileSync(outputPath, 'utf8'));
    const payload = JSON.parse(Buffer.from(envelope.payload, 'base64url').toString('utf8'));
    assert.equal(envelope.keyId, 'test-perpetual-key');
    assert.equal(payload.licenseTerm, 'perpetual');
    assert.equal(payload.validUntil, null);
    assert.equal(payload.maxDevices, 1);
  } finally { rmSync(dir, { recursive: true, force: true }); }
});
