import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const productsUi = readFileSync(new URL('../src/modules/products-ui.ts', import.meta.url), 'utf8');
const commerceUi = readFileSync(new URL('../src/modules/accounting-commerce-ui.ts', import.meta.url), 'utf8');
const importExport = readFileSync(new URL('../src/modules/import-export.ts', import.meta.url), 'utf8');

test('product catalog prices are entered in selected display currency and stored as integer Rial', () => {
  assert.match(productsUi, /parseMoneyToRial\(normalizeDigits\(val\('productPurchasePrice'/);
  assert.match(productsUi, /parseMoneyToRial\(normalizeDigits\(val\('productConsumerPrice'/);
  assert.match(productsUi, /parseMoneyToRial\(normalizeDigits\(val\('productPrice'/);
  assert.match(productsUi, /formatMoneyFromRial\(Math\.max\(0, Math\.round\(Number\(value\) \|\| 0\)\), productCurrency\(\)\)/);
});

test('opening stock valuation consumes catalog price as Rial without a second currency conversion', () => {
  assert.match(commerceUi, /const unitCostRial=Math\.round\(Number\(row\.unitHint\)\|\|0\)/);
  assert.match(commerceUi, /money\(Math\.round\(Number\(x\.unitHint\)\|\|0\)\)/);
  assert.doesNotMatch(commerceUi, /parseMoneyToRial\(String\(x\.unitHint\)/);
  assert.match(commerceUi, /formatMoneyFromRial\(Math\.round\(unit\),currency\)/);
});

test('product price exports declare Rial as the canonical storage unit', () => {
  assert.match(importExport, /'قیمت فروش \(ریال\)'/);
  assert.match(importExport, /'قیمت مصرف‌کننده \(ریال\)'/);
  assert.match(importExport, /'قیمت خرید \(ریال\)'/);
  assert.match(importExport, /قیمتفروشریال: 'price'/);
  assert.match(importExport, /قیمتمصرفکنندهریال: 'consumerPrice'/);
  assert.match(importExport, /قیمتخریدریال: 'purchasePrice'/);
});
