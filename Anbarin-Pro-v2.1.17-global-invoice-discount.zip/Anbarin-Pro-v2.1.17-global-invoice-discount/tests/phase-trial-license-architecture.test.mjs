import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { evaluateTrialStatus, TRIAL_DURATION_DAYS, TRIAL_DAY_MS } from '../src/modules/trial-license-core.ts';

const read = (path) => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

test('trial lifecycle has one central 14-day authority', () => {
  const trial = read('src/modules/trial-license.ts');
  const core = read('src/modules/trial-license-core.ts');
  const license = read('src/modules/license.ts');
  const modules = read('src/modules/license-modules.ts');
  assert.match(core, /TRIAL_DURATION_DAYS = 14/);
  assert.match(trial, /lastSeenAt: new Date\(now\)\.toISOString\(\)/);
  assert.match(trial, /refreshTrialLicense\(\)/);
  assert.match(license, /getTrialStatus\(now\)/);
  assert.match(modules, /getLicenseState\(\)\.trialActive/);
  assert.doesNotMatch(modules, /TRIAL_DAYS|firstAt.*14/);
});

test('native trial anchor is initialized before entitlement gates at boot', () => {
  const main = read('src/main.ts');
  assert.match(main, /await initializeTrialLicense\(\)/);
  assert.ok(main.indexOf('await initializeTrialLicense()') < main.indexOf('runBootRecovery()'));
  assert.ok(main.indexOf('await initializeTrialLicense()') < main.indexOf('applyLicenseModuleUI()'));
});

test('Android trial guard stores rollback-resistant state outside WebView storage', () => {
  const native = read('android/app/src/main/java/com/anbarian/app/TrialGuardPlugin.java');
  const activity = read('android/app/src/main/java/com/anbarian/app/MainActivity.java');
  assert.match(native, /getSharedPreferences\(PREFS/);
  assert.match(native, /Settings\.Secure\.ANDROID_ID/);
  assert.match(native, /CLOCK_TAMPER/);
  assert.match(native, /storedFingerprint == null \? fingerprint : storedFingerprint/);
  assert.match(native, /\.commit\(\)/);
  assert.match(activity, /registerPlugin\(TrialGuardPlugin\.class\)/);
});

test('existing paid-license device identity and signed offline license format remain unchanged', () => {
  const license = read('src/modules/license.ts');
  const offline = read('src/modules/offline-license.ts');
  assert.match(license, /configureOfflineLicenseDeviceIdProvider\(\(\) => getDeviceId\(\)\)/);
  assert.match(offline, /ANBARIN-LICENSE/);
  assert.match(license, /getDeviceId\(\)/);
});


test('trial is active for exactly 14 days and expires at the boundary', () => {
  const firstAt = '2026-01-01T00:00:00.000Z';
  const first = Date.parse(firstAt);
  const anchor = { firstAt, lastSeenAt: firstAt, clockTamper: false };
  assert.equal(TRIAL_DURATION_DAYS, 14);
  assert.equal(evaluateTrialStatus(anchor, first + 13 * TRIAL_DAY_MS).trialActive, true);
  assert.equal(evaluateTrialStatus(anchor, first + 14 * TRIAL_DAY_MS).trialActive, false);
  assert.equal(evaluateTrialStatus(anchor, first + 14 * TRIAL_DAY_MS).trialLeft, 0);
});

test('clock-tampered or malformed trial anchors fail closed', () => {
  const firstAt = '2026-01-01T00:00:00.000Z';
  const first = Date.parse(firstAt);
  assert.equal(evaluateTrialStatus({ firstAt, lastSeenAt: firstAt, clockTamper: true }, first + 1000).trialActive, false);
  assert.equal(evaluateTrialStatus({ firstAt: 'invalid', lastSeenAt: firstAt, clockTamper: false }, first).trialActive, false);
});
