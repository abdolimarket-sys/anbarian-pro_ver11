import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve(import.meta.dirname, '../src/modules/products-ui.ts'), 'utf8');
const start = source.indexOf('export async function deleteProduct');
const end = source.indexOf('/** اتصال از اسکن', start);
const block = source.slice(start, end);

test('product deletion is not blocked merely because a count session is closed', () => {
  assert.ok(start >= 0 && end > start, 'deleteProduct function must exist');
  assert.match(block, /guardPermission\('inventory\.edit'/);
  assert.doesNotMatch(block, /guardLocked\(/);
});

test('product deletion preserves count, stock, inventory-document and financial history', () => {
  assert.match(block, /countedQty != null/);
  assert.match(block, /countedQty2 != null/);
  assert.match(block, /hasOperationalStock/);
  assert.match(block, /hasInventoryDocumentHistory/);
  assert.match(block, /hasInvoiceHistory/);
  assert.match(block, /hasCostHistory/);
});
