import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

test('Android package identity remains fixed for in-place upgrades', () => {
  const gradle = read('android/app/build.gradle');
  const capacitor = read('capacitor.config.ts');
  assert.match(gradle, /applicationId\s+'com\.anbarian\.app'/);
  assert.match(capacitor, /appId:\s*'com\.anbarian\.app'/);
  assert.match(gradle, /versionCode\s+44/);
});

test('Release builds fail closed unless a persistent signing key is configured', () => {
  const gradle = read('android/app/build.gradle');
  const workflow = read('.github/workflows/main.yml');
  for (const name of ['ANBARIN_KEYSTORE_PATH', 'ANBARIN_KEYSTORE_PASSWORD', 'ANBARIN_KEY_ALIAS', 'ANBARIN_KEY_PASSWORD']) {
    assert.ok(gradle.includes(name), `Gradle missing ${name}`);
    assert.ok(workflow.includes(name), `workflow missing ${name}`);
  }
  assert.match(gradle, /requestsRelease\s*&&\s*!releaseSigningReady/);
  assert.match(gradle, /signingConfig\s+signingConfigs\.release/);
  assert.ok(workflow.includes('ANBARIN_SIGNING_CERT_SHA256'));
  assert.match(workflow, /if:\s*github\.event_name\s*==\s*'pull_request'/);
  assert.match(workflow, /if:\s*github\.event_name\s*!=\s*'pull_request'/);
  assert.doesNotMatch(workflow, /debug APK \(fallback/);
});

test('application version cache refresh does not erase durable app databases or preferences', () => {
  const activity = read('android/app/src/main/java/com/anbarian/app/MainActivity.java');
  assert.match(activity, /webView\.clearCache\(true\)/);
  assert.doesNotMatch(activity, /clear\(\)|clear\(\s*\)|deleteDatabase\("anbarin_db"\)|deleteDatabase\("WebView"\)/);
  assert.doesNotMatch(activity, /getSharedPreferences\([^)]*\)\.edit\(\)\.clear/);
});

test('IndexedDB upgrades use ordered migrations and never reset the user key-value store', () => {
  const storage = read('src/modules/storage.ts');
  assert.match(storage, /const DB_VERSION = 1/);
  assert.match(storage, /const DB_MIGRATIONS: Record<number/);
  assert.match(storage, /for \(let version = oldVersion \+ 1; version <= newVersion; version \+= 1\)/);
  assert.match(storage, /db\.createObjectStore\(STORE\)/);
  assert.doesNotMatch(storage, /indexedDB\.deleteDatabase|objectStore\(STORE\)\.clear\(/);
});
