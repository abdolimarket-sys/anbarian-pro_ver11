import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('invoice numbering is plain sequential digits without year, prefix or zero padding', () => {
  const source = read('src/modules/invoice-numbering.ts');
  assert.match(source, /return String\(highest \+ 1\)/);
  assert.doesNotMatch(source, /padStart/);
  assert.doesNotMatch(source, /invoice\.type !== type/);
});

test('legacy numbers are included across fiscal periods to prevent duplicates', () => {
  const source = read('src/modules/invoice-numbering.ts');
  assert.match(source, /قالب‌های قبلی/);
  assert.match(source, /raw\.match/);
  assert.doesNotMatch(source, /invoice\.fiscalPeriodId === fiscalPeriodId/);
});

test('invoice date change does not alter the sequential number', () => {
  const source = read('src/modules/accounting-commerce-ui.ts');
  assert.match(source, /function nextInvoiceNumber\(type:InvoiceType, _rawDate:string=todayJalali\(\)\):string/);
  assert.match(source, /numberInput\.value!==numberInput\.dataset\.generatedInvoiceNumber/);
});

test('invoice numbering and duplicate checks use one global sequence', () => {
  const source = read('src/modules/accounting-commerce-ui.ts');
  assert.match(source, /i\.id!==editingInvoiceId&&i\.number\.trim\(\)===invoiceNo/);
  const core = read('src/modules/accounting-commerce.ts');
  assert.match(core, /i\.id !== invoiceId && i\.number\.trim\(\) === input\.number\.trim\(\)/);
  assert.match(core, /i\.id!==invoice\.id&&i\.number\.trim\(\)===invoice\.number\.trim\(\)/);
});

test('default customer sales cannot be settled with an unpaid credit balance', () => {
  const source = read('src/modules/accounting-commerce-ui.ts');
  assert.match(source, /target\.type==='sale'&&target\.partyId===DEFAULT_CUSTOMER_PARTY_ID/);
  assert.match(source, /isDefaultCustomerSale&&total<requiredAmount/);
  assert.match(source, /confirmBtn\.disabled=isDefaultCustomerSale&&paid<requiredAmount/);
  const core = read('src/modules/accounting-commerce.ts');
  assert.match(core, /invoice\.type==='sale'&&invoice\.partyId===DEFAULT_CUSTOMER_PARTY_ID&&creditParts\.some/);
});
