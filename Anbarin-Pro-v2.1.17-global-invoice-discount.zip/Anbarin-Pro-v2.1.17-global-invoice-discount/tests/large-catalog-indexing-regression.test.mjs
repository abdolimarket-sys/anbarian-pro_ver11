import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const reports = read('src/modules/accounting-reports.ts');
const taxpayer = read('src/modules/taxpayer.ts');

test('accounting product and party reports resolve IDs through per-report indexes', () => {
  assert.match(reports, /const partyById = new Map\(commerce\.parties\.map\(p => \[p\.id, p\] as const\)\)/);
  assert.match(reports, /const productById = new Map\(products\.map\(p => \[p\.id, p\] as const\)\)/);
  assert.match(reports, /productById\.get\(line\.productId\)/);
  assert.doesNotMatch(reports, /commerce!?\.parties\.find\(/);
  assert.doesNotMatch(reports, /products\.find\(/);
});

test('open invoice reports aggregate valid allocations and endorsements in one pass', () => {
  assert.match(reports, /function buildInvoiceOutstandingIndex\(source: CommerceData\)/);
  assert.match(reports, /const allocatedByInvoice = new Map<string, number>\(\)/);
  assert.match(reports, /const endorsedByInvoice = new Map<string, number>\(\)/);
  assert.match(reports, /validTransactionIds\.has\(endorsement\.transactionId\)/);
  assert.doesNotMatch(reports, /invoiceOutstanding\(invoice\.id,commerce\)/);
});

test('taxpayer validation and draft generation index product mappings instead of repeated linear searches', () => {
  assert.match(taxpayer, /const mappingByProduct = mappingIndex \|\| new Map\(mappings\.map/);
  assert.match(taxpayer, /mappingByProduct\.get\(line\.productId\)/);
  assert.doesNotMatch(taxpayer, /mappings\.find\(/);
  assert.match(taxpayer, /const queuedInvoiceIds = new Set\(data\.queue\.map/);
});

test('product list filtering is cached across virtual scroll renders and invalidated on list refresh', () => {
  const lists = read('src/modules/product-list-controller.ts');
  assert.match(lists, /let filteredProductsCache: Product\[\] \| null = null/);
  assert.match(lists, /let filteredCountCache: Product\[\] \| null = null/);
  assert.match(lists, /if \(!filteredProductsCache\) filteredProductsCache = filterProductsAdvanced/);
  assert.match(lists, /if \(!filteredCountCache\) filteredCountCache = filterProductsAdvanced/);
  assert.match(lists, /function refreshLists\(\): void \{\s*invalidateFilteredCaches\(\)/);
});

test('opening-stock single-item product options are created only after user interaction', () => {
  const commerceUi = read('src/modules/accounting-commerce-ui.ts');
  assert.match(commerceUi, /data-lazy-product-options="true"/);
  assert.match(commerceUi, /openingProduct\.addEventListener\('focus'/);
  assert.match(commerceUi, /if \(openingProduct\.dataset\.lazyLoaded !== 'true'\)/);
  assert.doesNotMatch(commerceUi, /function productOptions\(\):string\{return products\.map/);
});
