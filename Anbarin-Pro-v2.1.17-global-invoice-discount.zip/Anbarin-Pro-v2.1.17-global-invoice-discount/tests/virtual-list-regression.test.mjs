import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/modules/virtual-list.ts', import.meta.url), 'utf8');

test('virtual list recreates rendered nodes so event handlers cannot retain a previous row item', () => {
  assert.match(source, /const row = renderRow\(items\[index\], index\)/);
  assert.match(source, /inner\.replaceChildren\(fragment\)/);
  assert.doesNotMatch(source, /el\.innerHTML\s*=\s*fresh\.innerHTML/);
  assert.doesNotMatch(source, /keyToEl|const pool:\s*HTMLElement\[\]/);
});

test('virtual list clamps stale scroll position after filtering or deleting rows', () => {
  assert.match(source, /const maxScrollTop = Math\.max\(0, height - viewHeight\)/);
  assert.match(source, /container\.scrollTop = scrollTop/);
  assert.match(source, /start = Math\.max\(0, Math\.min\(count - 1, start\)\)/);
});

test('virtual list keeps the empty state visible after the last item is filtered out', () => {
  assert.match(source, /if \(count === 0\) \{\s*container\.scrollTop = 0/);
  assert.match(source, /spacer\.style\.height = `\$\{Math\.max\(64, container\.clientHeight \|\| 64\)\}px`/);
});

test('virtual list validates row geometry and cleans up observers and scheduled frames', () => {
  assert.match(source, /Number\.isFinite\(requestedRowHeight\) && requestedRowHeight > 0/);
  assert.match(source, /resizeObserver\?\.disconnect\(\)/);
  assert.match(source, /cancelAnimationFrame\(raf\)/);
});
