import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const registry = readFileSync(join(root, 'src/modules/license-modules.ts'), 'utf8');
const catalog = JSON.parse(readFileSync(join(root, 'license-entitlements.json'), 'utf8'));
const issuer = readFileSync(join(root, 'scripts/issue-offline-license.mjs'), 'utf8');
const imports = readFileSync(join(root, 'src/modules/import-export-events.ts'), 'utf8');
const team = readFileSync(join(root, 'src/modules/team-photo-license-events.ts'), 'utf8');
const offline = readFileSync(join(root, 'src/modules/offline-license.ts'), 'utf8');
const accountingUi = readFileSync(join(root, 'src/modules/accounting-ui.ts'), 'utf8');
const license = readFileSync(join(root, 'src/modules/license.ts'), 'utf8');

test('entitlement registry is the single extension point for future capabilities', () => {
  for (const id of ['feature.taxpayer', 'feature.taxpayer_purchase_match', 'feature.export_excel', 'feature.team_sync']) assert.ok(id in catalog);
  assert.match(registry, /entitlementCatalog/);
  assert.match(issuer, /license-entitlements\.json/);
  assert.match(registry, /export function requireEntitlement/);
  assert.match(registry, /expandDependencies/);
  assert.match(registry, /مجوز معتبرِ صادرشده همیشه بر Trial اولویت دارد/);
  assert.match(registry, /licenseState\.licensed && !offline/);
});

test('base inventory remains available after trial without a license', () => {
  assert.match(registry, /new Set<string>\(\['module.count'\]\)/);
  assert.match(registry, /شمارش پایه رایگان/);
});

test('existing premium entry points use named entitlements', () => {
  assert.match(imports, /requireEntitlement\('feature\.export_excel'\)/);
  assert.match(imports, /requireEntitlement\('feature\.export_variance'\)/);
  assert.match(team, /requireEntitlement\('feature\.team_sync'\)/);
  assert.match(accountingUi, /tabId === 'taxpayer' && !requireEntitlement\('feature\.taxpayer'\)/);
});

test('new feature ids are preserved by both signed license formats', () => {
  assert.match(license, /features\?: string\[\]/);
  assert.match(license, /body\.features = \[\.\.\.new Set/);
  assert.match(offline, /features\?: string\[\]/);
  assert.match(offline, /p\.features/);
});
