import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeHealth } from '../src/modules/data-health-rules.ts';

const base = (overrides = {}) => ({
  products: [], auditValid: true, auditChecked: 0, auditLegacy: 0,
  accounting: { journalEntries: [] }, commerce: { parties: [], invoices: [] },
  costing: { balances: [] }, backupAvailable: true, backend: 'indexedDB', ...overrides,
});

test('duplicate barcode diagnostics expose every involved product and normalize Persian/Arabic digits', () => {
  const products = [
    { id: 'p1', name: 'کالای اول', code: '۱۲۳۴۵' },
    { id: 'p2', name: 'کالای دوم', code: '12345' },
    { id: 'p3', name: 'کالای سوم', code: '١٢٣٤٥' },
  ];
  const report = analyzeHealth(base({ products }));
  const finding = report.findings.find(x => x.code === 'product.barcode.duplicate');
  assert.ok(finding);
  assert.equal(finding.count, 2, 'count is duplicate excess records, not group count');
  assert.equal(finding.items.length, 3, 'all records in the duplicate group are listed');
  assert.deepEqual(finding.items.map(x => x.entityId), ['p1', 'p2', 'p3']);
  assert.ok(finding.items.every(x => x.action?.type === 'edit-product'));
});

test('invalid quantities and unbalanced posted journals include record-level context and safe guidance', () => {
  const report = analyzeHealth(base({
    products: [{ id: 'p9', name: 'کالای نامعتبر', systemQty: -2 }],
    accounting: { journalEntries: [{ id: 'j1', number: '1001', status: 'posted', lines: [{ debitRial: 100, creditRial: 0 }] }] },
  }));
  const qty = report.findings.find(x => x.code === 'inventory.product.quantity.invalid');
  const journal = report.findings.find(x => x.code === 'accounting.journal.unbalanced');
  assert.equal(qty.items[0].entityId, 'p9');
  assert.match(qty.remediation, /سند اصلاح موجودی/);
  assert.equal(journal.items[0].entityId, 'j1');
  assert.match(journal.items[0].secondary, /اختلاف: 100 ریال/);
  assert.match(journal.remediation, /سند اصلاحی/);
});

test('diagnostics are read-only and every finding has a stable machine code', () => {
  const product = { id: 'p1', name: 'کالا', code: 'ABC', systemQty: 0 };
  const products = [product, { ...product }];
  const before = structuredClone(products);
  const report = analyzeHealth(base({ products }));
  assert.deepEqual(products, before);
  assert.ok(report.findings.every(x => typeof x.code === 'string' && x.code.length > 0));
});
