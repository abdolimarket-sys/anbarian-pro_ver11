import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('inventory valuation renders bounded detail pages while preserving full-result totals', () => {
  const source = read('src/modules/accounting-reports.ts');
  assert.match(source, /INVENTORY_REPORT_PAGE_SIZE\s*=\s*100/);
  assert.match(source, /const qty=rows\.reduce/);
  assert.match(source, /const value=rows\.reduce/);
  assert.match(source, /const pageRows=rows\.slice/);
  assert.match(source, /جمع‌ها بر اساس تمام کالاهاست/);
});

test('taxpayer product mappings are lazy, indexed, searchable and paginated', () => {
  const source = read('src/modules/taxpayer.ts');
  assert.match(source, /id="taxMappingsFold"/);
  assert.match(source, /mappingsFold\?\.addEventListener\('toggle'/);
  assert.match(source, /new Map\(data\.productMappings\.map/);
  assert.match(source, /const pageSize = 100/);
  assert.match(source, /taxMappingSearch/);
  assert.doesNotMatch(source, /renderProductMappings\(root, data\);\s*void renderInvoices/);
});
