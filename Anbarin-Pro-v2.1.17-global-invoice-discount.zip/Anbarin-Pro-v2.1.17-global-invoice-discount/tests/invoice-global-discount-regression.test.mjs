import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { calculateInvoiceDiscountRial, allocateInvoiceDiscountRial } from '../src/modules/commerce-invoice-discount.ts';

const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');

test('invoice-wide percentage discount uses basis points and exact rial rounding', () => {
  assert.equal(calculateInvoiceDiscountRial(1_000_000, 'percent', 1250), 125_000);
  assert.equal(calculateInvoiceDiscountRial(999, 'percent', 3333), 333);
});

test('invoice-wide fixed discount is bounded by invoice subtotal', () => {
  assert.equal(calculateInvoiceDiscountRial(1_000_000, 'amount', 125_500), 125_500);
  assert.throws(() => calculateInvoiceDiscountRial(1_000_000, 'amount', 1_000_000), /کمتر/);
  assert.throws(() => calculateInvoiceDiscountRial(1_000_000, 'amount', 1_000_001), /کمتر/);
});

test('invoice discount allocation is deterministic and conserves every rial', () => {
  const shares = allocateInvoiceDiscountRial([100, 200, 700], 101);
  assert.deepEqual(shares, [10, 20, 71]);
  assert.equal(shares.reduce((sum, value) => sum + value, 0), 101);
  assert.deepEqual(allocateInvoiceDiscountRial([100, 200], 0), [0, 0]);
});

test('invoice discount controls, persistence and downstream print are connected', () => {
  const model = read('../src/modules/accounting-commerce.ts');
  const ui = read('../src/modules/accounting-commerce-ui.ts');
  const template = read('../src/modules/commerce-ui-invoice.ts');
  const print = read('../src/modules/commerce-ui-print.ts');
  assert.match(model, /invoiceDiscountAllocatedRial/);
  assert.match(model, /invoiceDiscountType,invoiceDiscountValue,invoiceDiscountRial/);
  assert.match(ui, /invoiceDiscountType/);
  assert.match(ui, /invoiceDiscountValue/);
  assert.match(ui, /calculateInvoiceDiscountRial/);
  assert.match(template, /id="invoiceDiscountType"/);
  assert.match(template, /id="invoiceDiscountValue"/);
  assert.match(print, /تخفیف کل فاکتور/);
});
