/**
 * لایسنس ماژولار انبارین
 * — شمارش/انبار (count)
 * — حسابداری (accounting)
 * — کامل (هر دو)
 *
 * سازگار با لایسنس‌های قدیمی بدون فیلد modules.
 * زیرساخت آنلاین: lease سرور از license-platform.
 */

import { getOfflineLicense, ensureOfflineLicenseIntegrity } from './offline-license';
import { getStoredLicense, getLicenseState } from './license';
import { getCachedLicenseLease } from './license-platform';
import { toast } from './ui';
import { showPage } from './ui';
import entitlementCatalog from '../../license-entitlements.json';

/**
 * هسته متمرکز مجوزها (Entitlement Registry)
 * هر قابلیت تجاری با شناسه پایدار ثبت می‌شود؛ UI فقط بازتاب وضعیت دسترسی است.
 * شمارش پایه عمداً رایگان است و با پایان Trial قفل نمی‌شود.
 */
export type AppModuleId = 'count' | 'accounting';
export type EntitlementId = keyof typeof entitlementCatalog;

export interface EntitlementDefinition {
  id: EntitlementId;
  label: string;
  module?: AppModuleId;
  dependencies?: EntitlementId[];
  includedInTrial: boolean;
  legacyPremium?: boolean;
}

/** منبع واحد کاتالوگ برای برنامه و ابزار امن صدور لایسنس؛ شناسه قابلیت فقط یک‌بار تعریف می‌شود. */
const catalog = entitlementCatalog as Record<string, Omit<EntitlementDefinition, 'id'>>;
export const ENTITLEMENT_REGISTRY = Object.fromEntries(
  Object.entries(catalog).map(([id, definition]) => [id, { id, ...definition }]),
) as Readonly<Record<EntitlementId, EntitlementDefinition>>;

export const APP_MODULE_LABELS: Record<AppModuleId, string> = { count: 'شمارش و انبار', accounting: 'حسابداری' };
const ALL_MODULES: AppModuleId[] = ['count', 'accounting'];
const ALL_ENTITLEMENTS = Object.keys(ENTITLEMENT_REGISTRY) as EntitlementId[];

function cleanIds(values: unknown): string[] {
  if (!Array.isArray(values)) return [];
  return [...new Set(values.map((v) => String(v || '').trim().toLowerCase()).filter(Boolean))];
}

export function modulesFromPlan(plan: string | undefined | null): AppModuleId[] {
  const p = String(plan || '').trim().toLowerCase();
  if (!p || p === 'none') return [];
  if (p === 'count' || p === 'inventory' || p === 'stock' || p === 'warehouse' || p === 'starter') return ['count'];
  if (p === 'accounting' || p === 'acc' || p === 'finance' || p === 'commerce') return ['accounting'];
  // رفتار طرح‌های قدیمی حفظ می‌شود؛ طرح ناشناخته مانند قبل full تفسیر می‌شود.
  return [...ALL_MODULES];
}

function resolveGrantedEntitlements(): Set<string> {
  const granted = new Set<string>(['module.count']); // شمارش پایه رایگان، حتی پس از اتمام Trial
  const offline = getOfflineLicense();
  const licenseState = getLicenseState();
  // رکورد منقضی‌شده در localStorage نباید به‌عنوان مجوز فعال شمرده شود.
  const stored = licenseState.licensed && !offline ? getStoredLicense() : null;
  const lease = getCachedLicenseLease();
  const trial = isTrialActiveLocal();
  const source: any = offline || stored || lease;

  // مجوز معتبرِ صادرشده همیشه بر Trial اولویت دارد؛ Trial نباید دامنه مجوز محدود را گسترش دهد.
  if (!source) {
    if (trial) for (const id of ALL_ENTITLEMENTS) if (ENTITLEMENT_REGISTRY[id].includedInTrial) granted.add(id);
    return expandDependencies(granted);
  }

  const explicit = cleanIds(source.features || source.entitlements?.features);
  for (const id of explicit) if (id in ENTITLEMENT_REGISTRY) granted.add(id);

  const modules = cleanIds(source.modules);
  const planModules = modules.length
    ? modules.filter((m) => m === 'count' || m === 'accounting') as AppModuleId[]
    : modulesFromPlan(source.plan);
  for (const module of planModules) granted.add(`module.${module}`);

  // مجوزهای قدیمی full/pro تا زمان مهاجرت بدون افت دسترسی کار کنند.
  // قابلیت‌های جدید (مانند مودیان) نیازمند شناسه entitlement صریح هستند.
  const legacyFull = !explicit.length && !Array.isArray(source.features) && !source.features?.length
    && (!modules.length || ['full','pro','professional','enterprise','complete','standard'].includes(String(source.plan || '').toLowerCase()));
  if (legacyFull) {
    for (const id of ALL_ENTITLEMENTS) if (ENTITLEMENT_REGISTRY[id].legacyPremium) granted.add(id);
  }
  return expandDependencies(granted);
}

function expandDependencies(initial: Set<string>): Set<string> {
  const result = new Set(initial);
  let changed = true;
  while (changed) {
    changed = false;
    for (const id of [...result]) {
      const def = ENTITLEMENT_REGISTRY[id as EntitlementId];
      for (const dependency of def?.dependencies || []) {
        if (!result.has(dependency)) { result.add(dependency); changed = true; }
      }
    }
  }
  return result;
}

function isTrialActiveLocal(): boolean {
  try { return getLicenseState().trialActive; } catch { return false; }
}

export function getActiveEntitlements(): EntitlementId[] {
  const granted = resolveGrantedEntitlements();
  return ALL_ENTITLEMENTS.filter((id) => granted.has(id));
}

export function hasEntitlement(id: EntitlementId): boolean {
  return resolveGrantedEntitlements().has(id);
}

export function requireEntitlement(id: EntitlementId): boolean {
  if (hasEntitlement(id)) return true;
  const definition = ENTITLEMENT_REGISTRY[id];
  toast(`برای استفاده از «${definition.label}» باید مجوز این قابلیت را فعال کنید. از بخش تنظیمات لایسنس اقدام کنید.`, 'error');
  showPage('admin');
  return false;
}

export function getActiveModules(): AppModuleId[] {
  return ALL_MODULES.filter((module) => hasEntitlement(`module.${module}` as EntitlementId));
}

export function hasModule(module: AppModuleId): boolean { return hasEntitlement(`module.${module}` as EntitlementId); }

export function requireModule(module: AppModuleId, featureLabel?: string): boolean {
  if (hasModule(module)) return true;
  toast(`دسترسی به «${featureLabel || APP_MODULE_LABELS[module]}» نیاز به لایسنس ${APP_MODULE_LABELS[module]} دارد. از تنظیمات لایسنس را فعال کنید.`, 'error');
  showPage('admin');
  return false;
}

export function describeActiveModules(): string {
  const mods = getActiveModules();
  const licensed = !!getOfflineLicense() || !!getStoredLicense() || !!getCachedLicenseLease();
  if (isTrialActiveLocal()) return 'آزمایشی — دسترسی کامل تا پایان دوره';
  if (mods.includes('count') && mods.includes('accounting')) return licensed ? 'کامل (شمارش + حسابداری)' : 'شمارش پایه رایگان + حسابداری قفل';
  if (mods.includes('count')) return licensed ? 'شمارش و انبار — لایسنس فعال' : 'شمارش و انبار پایه — رایگان';
  return 'شمارش پایه رایگان';
}

export function applyLicenseModuleUI(): void {
  void ensureOfflineLicenseIntegrity();

  const canCount = hasModule('count');
  const canAcc = hasModule('accounting');

  document.querySelectorAll<HTMLElement>('.nav-item[data-page]').forEach((btn) => {
    const page = btn.dataset.page || '';
    let allowed = true;
    if (page === 'count' || page === 'products' || page === 'reports') allowed = canCount;
    else if (page === 'accounting') allowed = canAcc;
    btn.style.display = allowed ? '' : 'none';
    btn.toggleAttribute('disabled', !allowed);
    btn.classList.toggle('module-locked', !allowed);
  });

  const lock = (id: string, on: boolean) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.toggle('module-locked', on);
    if (on) el.setAttribute('aria-disabled', 'true');
    else el.removeAttribute('aria-disabled');
  };
  lock('page-count', !canCount);
  lock('page-products', !canCount);
  lock('page-reports', !canCount);
  lock('page-accounting', !canAcc);

  const active = document.querySelector('.page.active') as HTMLElement | null;
  if (active) {
    const id = active.id || '';
    if ((id === 'page-count' || id === 'page-products' || id === 'page-reports') && !canCount) showPage('admin');
    else if (id === 'page-accounting' && !canAcc) showPage('admin');
  }

  const detail = document.getElementById('licenseModuleDetail');
  if (detail) detail.textContent = describeActiveModules();
}

export function moduleForPage(page: string): AppModuleId | null {
  if (page === 'count' || page === 'products' || page === 'reports') return 'count';
  if (page === 'accounting') return 'accounting';
  return null;
}
