/** قواعد دامنه سلامت داده‌ها؛ خالص، قطعی، بدون DOM و بدون نوشتن در ذخیره‌ساز. */
import type { HealthFinding, HealthLevel, HealthReport, HealthIssueDetail } from './data-health.types';

const normalizeCode = (value: unknown): string => String(value ?? '').trim()
  .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
  .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d))).toLowerCase();
const label = (value: unknown, fallback = 'بدون عنوان'): string => String(value ?? '').trim() || fallback;

export function analyzeHealth(input: {
  products: any[]; auditValid: boolean; auditChecked: number; auditLegacy: number;
  accounting: any; commerce: any; costing: any; backupAvailable: boolean; backend: string;
}): HealthReport {
  const findings: HealthFinding[] = [];
  const add = (code: string, level: HealthLevel, title: string, detail: string, count?: number,
    items?: HealthIssueDetail[], remediation?: string) => findings.push({ code, level, title, detail, count, items, remediation });

  const idGroups = new Map<string, any[]>();
  const codeGroups = new Map<string, any[]>();
  const invalidProducts: any[] = [];
  for (const p of input.products || []) {
    const id = String(p?.id ?? '').trim();
    const idKey = id || '__EMPTY_ID__';
    idGroups.set(idKey, [...(idGroups.get(idKey) || []), p]);
    const code = normalizeCode(p?.code);
    if (code) codeGroups.set(code, [...(codeGroups.get(code) || []), p]);
    if (!Number.isFinite(Number(p?.systemQty)) || Number(p.systemQty) < 0) invalidProducts.push(p);
  }
  const duplicateIdGroups = [...idGroups.entries()].filter(([id, rows]) => id === '__EMPTY_ID__' || rows.length > 1);
  const duplicateIdCount = duplicateIdGroups.reduce((n, [, rows]) => n + (rows.length > 1 ? rows.length - 1 : rows.length), 0);
  const duplicateCodeGroups = [...codeGroups.entries()].filter(([, rows]) => rows.length > 1);
  const duplicateCodeCount = duplicateCodeGroups.reduce((n, [, rows]) => n + rows.length - 1, 0);

  if (duplicateIdCount) add('product.identity.duplicate', 'error', 'شناسه کالای خالی یا تکراری',
    `${duplicateIdCount} رکورد دارای شناسه خالی یا تکراری است.`, duplicateIdCount,
    duplicateIdGroups.flatMap(([id, rows]) => rows.map(p => ({ entityType: 'product' as const, entityId: String(p?.id ?? ''), primary: label(p?.name), secondary: id === '__EMPTY_ID__' ? 'شناسه خالی' : `شناسه: ${id}` }))),
    'شناسه کالا باید یکتا و غیرخالی باشد. پیش از اصلاح، وابستگی اسناد و گردش‌های هر کالا بررسی شود؛ شناسه سوابق مالی را دستی تغییر ندهید.');
  else add('product.identity.unique', 'ok', 'شناسه کالاها', 'شناسه کالاها تکراری نیست.');

  if (duplicateCodeCount) add('product.barcode.duplicate', 'warning', 'بارکدهای تکراری',
    `${duplicateCodeCount} رکورد اضافه در گروه‌های بارکد تکراری وجود دارد (${duplicateCodeGroups.length} بارکد یکتا درگیر است).`, duplicateCodeCount,
    duplicateCodeGroups.flatMap(([code, rows]) => rows.map(p => ({ entityType: 'product' as const, entityId: String(p?.id ?? ''), primary: label(p?.name), secondary: `بارکد: ${code}`, action: p?.id ? { type: 'edit-product' as const, entityId: String(p.id), label: 'ویرایش کالا' } : undefined }))),
    'برای هر بارکد باید فقط یک کالای فعال وجود داشته باشد. کالاهای درگیر را بازبینی و بارکد صحیح هر کالا را از فرم استاندارد کالا اصلاح کنید؛ حذف خودکار انجام نمی‌شود.');
  else add('product.barcode.unique', 'ok', 'یکتایی بارکد', 'بارکد تکراری در فهرست فعلی پیدا نشد.');

  if (invalidProducts.length) add('inventory.product.quantity.invalid', 'error', 'مقادیر موجودی نامعتبر',
    `${invalidProducts.length} کالا مقدار موجودی منفی یا غیرعددی دارد.`, invalidProducts.length,
    invalidProducts.map(p => ({ entityType: 'product', entityId: String(p?.id ?? ''), primary: label(p?.name), secondary: `مقدار ثبت‌شده: ${String(p?.systemQty ?? 'خالی')}` })),
    'موجودی را مستقیماً در این گزارش اصلاح نکنید. ابتدا کارت کالا و گردش انبار را بررسی و سپس از سند اصلاح موجودی/انبار استفاده کنید تا آثار حسابداری و بهای تمام‌شده حفظ شود.');
  else add('inventory.product.quantity.valid', 'ok', 'مقادیر موجودی', 'مقادیر موجودی عملیاتی معتبر هستند.');

  if (!input.auditValid) add('audit.chain.invalid', 'error', 'سلامت زنجیره لاگ', 'امضای زنجیره‌ای تاریخچه عملیات ناسازگار است؛ لاگ را پاک یا بازنویسی نکنید و نسخه پشتیبان را بررسی کنید.', undefined, [], 'این مورد با ویرایش دستی قابل اصلاح نیست؛ نسخه پشتیبان معتبر و رویدادهای ممیزی را با پشتیبانی فنی بررسی کنید.');
  else add('audit.chain.valid', 'ok', 'سلامت زنجیره لاگ', `${input.auditChecked} رویداد امضاشده بررسی شد؛ ${input.auditLegacy} رویداد قدیمی بدون امضا وجود دارد.`);

  const a = input.accounting || {};
  const journals = a.journalEntries || [];
  const unbalanced: any[] = [];
  const journalIdGroups = new Map<string, any[]>();
  const journalNumberGroups = new Map<string, any[]>();
  for (const j of journals) {
    const id = String(j?.id ?? '').trim();
    journalIdGroups.set(id || '__EMPTY__', [...(journalIdGroups.get(id || '__EMPTY__') || []), j]);
    const number = String(j?.number ?? '').trim();
    if (number) journalNumberGroups.set(number, [...(journalNumberGroups.get(number) || []), j]);
    if (j?.status === 'posted') {
      const debit = (j.lines || []).reduce((s: number, l: any) => s + (Number(l.debitRial) || 0), 0);
      const credit = (j.lines || []).reduce((s: number, l: any) => s + (Number(l.creditRial) || 0), 0);
      if (!Number.isFinite(debit) || !Number.isFinite(credit) || Math.abs(debit - credit) > 0) unbalanced.push({ j, debit, credit });
    }
  }
  if (unbalanced.length) add('accounting.journal.unbalanced', 'error', 'اسناد قطعی نامتوازن',
    `${unbalanced.length} سند قطعی تراز بدهکار و بستانکار ندارد.`, unbalanced.length,
    unbalanced.map(({ j, debit, credit }) => ({ entityType: 'journal', entityId: String(j.id ?? ''), primary: `سند ${label(j.number, String(j.id ?? '').slice(0, 8))}`, secondary: `بدهکار: ${debit} ریال | بستانکار: ${credit} ریال | اختلاف: ${debit - credit} ریال` })),
    'سند قطعی را مستقیم در دیتابیس تغییر ندهید. سند، ردیف‌ها، ارز/واحد مبلغ و سند منبع بررسی شود؛ اصلاح حسابداری باید با سند اصلاحی یا ابطال و ثبت جایگزین طبق گردش مصوب انجام شود.');
  else add('accounting.journal.balanced', 'ok', 'توازن اسناد قطعی', 'اسناد قطعی موجود از نظر جمع بدهکار و بستانکار متوازن هستند.');

  const duplicateJournals = [
    ...[...journalIdGroups.entries()].filter(([k, rows]) => k === '__EMPTY__' || rows.length > 1).flatMap(([k, rows]) => rows.map(j => ({ j, reason: k === '__EMPTY__' ? 'شناسه خالی' : `شناسه تکراری: ${k}` }))),
    ...[...journalNumberGroups.entries()].filter(([, rows]) => rows.length > 1).flatMap(([k, rows]) => rows.map(j => ({ j, reason: `شماره تکراری: ${k}` }))),
  ];
  if (duplicateJournals.length) add('accounting.journal.identity.duplicate', 'warning', 'شناسه یا شماره سند تکراری',
    `${duplicateJournals.length} رکورد سند دارای شناسه یا شماره تکراری است.`, duplicateJournals.length,
    duplicateJournals.map(({ j, reason }) => ({ entityType: 'journal', entityId: String(j?.id ?? ''), primary: `سند ${label(j?.number, String(j?.id ?? '').slice(0, 8))}`, secondary: reason })),
    'شماره‌گذاری و شناسه سند را بدون بررسی ارتباط سند با فاکتور/تراکنش تغییر ندهید. اسناد قطعی تکراری باید از مسیر اصلاح حسابداری تعیین تکلیف شوند.');

  const commerce = input.commerce || {};
  const parties = new Map((commerce.parties || []).map((p: any) => [String(p.id), p]));
  const orphanInvoices = (commerce.invoices || []).filter((i: any) => i.partyId && !parties.has(String(i.partyId)));
  if (orphanInvoices.length) add('commerce.invoice.party.missing', 'warning', 'فاکتور با طرف حساب ناموجود',
    `${orphanInvoices.length} فاکتور به طرف‌حسابی ارجاع می‌دهد که در فهرست طرف‌حساب‌ها نیست.`, orphanInvoices.length,
    orphanInvoices.map((i: any) => ({ entityType: 'invoice', entityId: String(i.id ?? ''), primary: `فاکتور ${label(i.number, String(i.id ?? '').slice(0, 8))}`, secondary: `شناسه طرف حساب مفقود: ${String(i.partyId)}` })),
    'فاکتور و شناسه طرف‌حساب را تطبیق دهید. طرف‌حساب را در صورت امکان با شناسه صحیح بازیابی کنید؛ سند قطعی را حذف یا به طرف حساب دیگری منتسب نکنید مگر با سند اصلاحی.');

  const costing = input.costing || {};
  const balanceGroups = new Map<string, any[]>();
  for (const b of costing.balances || []) {
    const key = `${b.productId}|${b.warehouse}`;
    balanceGroups.set(key, [...(balanceGroups.get(key) || []), b]);
  }
  const duplicateBalances = [...balanceGroups.values()].filter(rows => rows.length > 1).flat();
  const negativeBalances = (costing.balances || []).filter((b: any) => Number(b.qtyMilli) < 0);
  const badCost = (costing.balances || []).filter((b: any) => !Number.isFinite(Number(b.valueRial)) || Number(b.valueRial) < 0);
  if (duplicateBalances.length) add('costing.balance.duplicate', 'error', 'مانده بهای تمام‌شده تکراری',
    `${duplicateBalances.length} رکورد در ترکیب‌های تکراری کالا/انبار یافت شد.`, duplicateBalances.length,
    duplicateBalances.map((b: any) => ({ entityType: 'balance', entityId: String(b.id ?? ''), primary: `کالا: ${String(b.productId ?? 'نامشخص')}`, secondary: `انبار: ${String(b.warehouse ?? 'نامشخص')} | مقدار: ${String(b.qtyMilli ?? 'نامشخص')}` })),
    'مانده بهای تمام‌شده را دستی ادغام یا حذف نکنید. گردش‌ها و لایه‌های بهای تمام‌شده را بررسی کنید و از فرایند بازسازی/تطبیق رسمی استفاده شود.');
  if (negativeBalances.length) add('costing.balance.negative', 'warning', 'مانده منفی بهای تمام‌شده',
    `${negativeBalances.length} مانده منفی شناسایی شد.`, negativeBalances.length,
    negativeBalances.map((b: any) => ({ entityType: 'balance', entityId: String(b.id ?? ''), primary: `کالا: ${String(b.productId ?? 'نامشخص')}`, secondary: `انبار: ${String(b.warehouse ?? 'نامشخص')} | مقدار: ${String(b.qtyMilli)}` })),
    'ترتیب زمانی اسناد ورود/خروج، انبار و واحد کالا را بررسی کنید. مانده را با عددسازی مستقیم اصلاح نکنید؛ سند اصلاح موجودی لازم است.');
  if (badCost.length) add('costing.balance.value.invalid', 'error', 'ارزش‌گذاری نامعتبر',
    `${badCost.length} مانده ارزش ریالی نامعتبر دارد.`, badCost.length,
    badCost.map((b: any) => ({ entityType: 'balance', entityId: String(b.id ?? ''), primary: `کالا: ${String(b.productId ?? 'نامشخص')}`, secondary: `انبار: ${String(b.warehouse ?? 'نامشخص')} | ارزش: ${String(b.valueRial)}` })),
    'ارزش ریالی باید از لایه‌ها و گردش‌های بهای تمام‌شده بازسازی شود. مقدار ارزش را دستی تغییر ندهید.');

  if (!input.backupAvailable) add('backup.auto.missing', 'warning', 'نسخه پشتیبان خودکار پیدا نشد', 'کلید پشتیبان خودکار در ذخیره‌ساز در دسترس نیست؛ پیش از عملیات حساس، خروجی پشتیبان مستقل بگیرید.', undefined, [], 'پشتیبان مستقل تهیه و امکان بازیابی آن را در محیط آزمایشی بررسی کنید.');
  else add('backup.auto.available', 'ok', 'وجود نسخه پشتیبان خودکار', 'حداقل یک نسخه پشتیبان خودکار در ذخیره‌ساز پیدا شد.');
  if (input.backend === 'localStorage') add('storage.fallback.active', 'warning', 'ذخیره‌سازی جایگزین', 'برنامه از ذخیره‌سازی جایگزین استفاده می‌کند؛ وضعیت پایداری داده را بررسی کنید.', undefined, [], 'علت در دسترس نبودن ذخیره‌ساز اصلی و سلامت IndexedDB بررسی شود.');
  else add('storage.backend.status', 'info', 'وضعیت ذخیره‌سازی', `مسیر ذخیره‌سازی گزارش‌شده: ${input.backend}.`);

  const totals = { errors: findings.filter(x => x.level === 'error').length, warnings: findings.filter(x => x.level === 'warning').length, info: findings.filter(x => x.level === 'info').length, ok: findings.filter(x => x.level === 'ok').length };
  return { checkedAt: new Date().toISOString(), findings, totals };
}
