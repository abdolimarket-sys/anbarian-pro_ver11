/** Pure trial-domain rules; no browser, storage, or platform dependencies. */
export const TRIAL_DURATION_DAYS = 14;
export const TRIAL_DAY_MS = 24 * 60 * 60 * 1000;

export interface TrialClockSnapshot {
  firstAt: string;
  lastSeenAt: string;
  clockTamper: boolean;
}

export interface TrialStatusSnapshot {
  firstAt: string;
  trialEnd: string;
  trialLeft: number;
  trialActive: boolean;
  clockTamper: boolean;
}

export function evaluateTrialStatus(snapshot: TrialClockSnapshot, now = Date.now()): TrialStatusSnapshot {
  const first = Date.parse(snapshot.firstAt);
  const end = first + TRIAL_DURATION_DAYS * TRIAL_DAY_MS;
  const effectiveEnd = snapshot.clockTamper ? first : end;
  const validStart = Number.isFinite(first) && first > 0;
  return {
    firstAt: snapshot.firstAt,
    trialEnd: new Date(Number.isFinite(effectiveEnd) ? effectiveEnd : 0).toISOString(),
    trialLeft: validStart ? Math.max(0, Math.ceil((effectiveEnd - now) / TRIAL_DAY_MS)) : 0,
    trialActive: validStart && now < effectiveEnd && !snapshot.clockTamper,
    clockTamper: snapshot.clockTamper,
  };
}
