/** سرویس هماهنگ‌کننده بررسی سلامت؛ دریافت snapshot و اجرای قواعد دامنه. */
import { products, verifyAuditIntegrity, storageBackend } from './state';
import { idbGet } from './storage';
import { loadAccountingData } from './accounting';
import { loadCommerceData } from './accounting-commerce';
import { loadInventoryCostData } from './inventory-costing';
import { analyzeHealth } from './data-health-rules';
import type { HealthLevel, HealthReport, HealthIssueDetail } from './data-health.types';

export async function collectHealthReport():Promise<HealthReport>{
  const [accounting,commerce,costing,backup,previous]=await Promise.all([
    loadAccountingData(),loadCommerceData(),loadInventoryCostData(),idbGet<unknown>('autobackup').catch(()=>undefined),idbGet<unknown>('autobackup_prev').catch(()=>undefined)
  ]);
  const audit=verifyAuditIntegrity();
  const report=analyzeHealth({products,auditValid:audit.valid,auditChecked:audit.checked,auditLegacy:audit.legacy,accounting,commerce,costing,backupAvailable:!!backup||!!previous,backend:storageBackend});
  // یکپارچگی مالی (فاکتور/سند/موجودی/Journal)
  try {
    const { runFinancialIntegrityCheck } = await import('./financial-integrity-check');
    const fin = await runFinancialIntegrityCheck();
    const titleMap: Record<string, string> = {
      pending_operation: 'عملیات مالی نیمه‌تمام',
      invoice_missing_journal: 'فاکتور بدون سند حسابداری',
      duplicate_posted_journal: 'سند حسابداری قطعی تکراری برای یک منبع',
      invoice_missing_movement: 'فاکتور بدون گردش انبار',
      cash_missing_journal: 'تراکنش بدون سند حسابداری',
      stock_card_divergence: 'ناهم‌خوانی موجودی کارت و بهای تمام‌شده',
    };
    for (const f of fin.findings) {
      const level: HealthLevel = f.severity === 'error' ? 'error' : f.severity === 'warn' ? 'warning' : 'info';
      const title = titleMap[f.code] || `مالی — ${f.code}`;
      const sourceType: HealthIssueDetail['entityType'] = f.entityType || (
        f.code === 'party_subledger_mismatch' || f.code === 'missing_party_reference' ? 'party' :
        f.code === 'cash_ledger_mismatch' ? 'cash-account' :
        f.code === 'unallocated_settlement' ? 'transaction' : 'system'
      );
      const entityIds = f.entityIds?.length ? f.entityIds : (f.entityId ? [f.entityId] : []);
      const items: HealthIssueDetail[] = entityIds.map(entityId => ({
        entityType: sourceType, entityId,
        primary: sourceType === 'invoice' ? `فاکتور مرجع: ${entityId}` : sourceType === 'journal' ? `سند حسابداری: ${entityId}` : sourceType === 'product' ? `شناسه کالا: ${entityId}` : sourceType === 'party' ? `طرف‌حساب: ${entityId}` : sourceType === 'cash-account' ? `حساب نقد/بانک: ${entityId}` : sourceType === 'transaction' ? `تراکنش: ${entityId}` : `شناسه مرجع: ${entityId}`,
        secondary: f.relatedEntityId ? `شناسه مرتبط: ${f.relatedEntityId}` : undefined,
      }));
      report.findings.push({ code: `finance.${f.code}`, level, title, detail: f.message, items,
        remediation: 'این مغایرت فقط با بررسی سند/تراکنش مرجع و استفاده از گردش اصلاحی همان ماژول قابل رفع است. از حذف یا ویرایش مستقیم داده‌های قطعی خودداری کنید.' });
    }
    if (!fin.findings.length) {
      report.findings.push({ code: 'finance.integrity.ok', level: 'ok', title: 'یکپارچگی مالی', detail: 'فاکتور، اسناد، گردش انبار و Journal ناسازگاری ساختاری ندارند.' });
    }
    report.totals = {
      errors: report.findings.filter(x => x.level === 'error').length,
      warnings: report.findings.filter(x => x.level === 'warning').length,
      info: report.findings.filter(x => x.level === 'info').length,
      ok: report.findings.filter(x => x.level === 'ok').length,
    };
  } catch (e) {
    report.findings.push({ code: 'finance.integrity.check_failed', level: 'warning', title: 'بررسی یکپارچگی مالی', detail: e instanceof Error ? e.message : 'اجرا نشد' });
    report.totals.warnings += 1;
  }
  return report;
}

