export type InvoiceNumberType = 'sale' | 'purchase' | 'return-sale' | 'return-purchase' | 'proforma';

export interface InvoiceNumberingRecord {
  type: InvoiceNumberType;
  number: string;
  fiscalPeriodId: string;
}

/** شماره داخلی ساده و پیوسته؛ مستقل از سال مالی و بدون پیشوند/صفرگذاری. */
export function nextStandardInvoiceNumber(
  _type: InvoiceNumberType,
  _fiscalYear: string,
  _fiscalPeriodId: string,
  invoices: readonly InvoiceNumberingRecord[],
): string {
  let highest = 0;
  for (const invoice of invoices) {
    const raw = invoice.number.trim();
    // شماره‌های جدید عدد ساده‌اند؛ قالب‌های قبلی نیز برای جلوگیری از تکرار خوانده می‌شوند.
    const match = raw.match(/^(?:\d+|\d{4}-[A-Z]+-\d+|[A-Z]+-?\d+)$/i);
    if (!match) continue;
    const value = Number(raw.match(/(\d+)$/)?.[1] || 0);
    if (Number.isSafeInteger(value) && value > highest) highest = value;
  }
  return String(highest + 1);
}

export function invoiceNumberPrefix(_type: InvoiceNumberType): string {
  return '';
}
