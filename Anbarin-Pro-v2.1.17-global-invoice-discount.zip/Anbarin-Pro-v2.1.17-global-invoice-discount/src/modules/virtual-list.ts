/**
 * فهرست مجازی سبک و ایمن برای داده‌های حجیم.
 * فقط ردیف‌های داخل viewport به‌همراه overscan در DOM ساخته می‌شوند.
 * هر بار که پنجره نمایش تغییر می‌کند، ردیف‌ها با renderer تازه ساخته می‌شوند
 * تا event listenerهای وابسته به داده، به ردیف قبلی متصل نمانند.
 */

export interface VirtualListOptions<T> {
  /** عنصر اسکرول‌شونده (معمولاً خود container) */
  container: HTMLElement;
  /** ارتفاع ثابت هر ردیف به پیکسل */
  rowHeight: number;
  /** تعداد ردیف اضافه بالا/پایین viewport */
  overscan?: number;
  /** داده */
  getItems: () => T[];
  /** رندر یک ردیف — باید HTMLElement مستقل برگرداند */
  renderRow: (item: T, index: number) => HTMLElement;
  /** کلید پایدار برای شناسایی ردیف (اختیاری؛ برای سازگاری API حفظ شده) */
  getKey?: (item: T, index: number) => string;
  /** کلاس روی spacer/inner */
  className?: string;
}

export interface VirtualListHandle {
  refresh: () => void;
  scrollToIndex: (index: number, align?: 'start' | 'center' | 'end') => void;
  destroy: () => void;
}

export function createVirtualList<T>(options: VirtualListOptions<T>): VirtualListHandle {
  const {
    container,
    rowHeight: requestedRowHeight,
    overscan: requestedOverscan = 6,
    getItems,
    renderRow,
    className,
  } = options;
  const rowHeight = Number.isFinite(requestedRowHeight) && requestedRowHeight > 0
    ? requestedRowHeight
    : 1;
  const overscan = Number.isFinite(requestedOverscan)
    ? Math.max(0, Math.floor(requestedOverscan))
    : 6;

  // ساختار DOM: container > spacer (ارتفاع کل) > inner (پنجره قابل‌مشاهده)
  container.style.position = container.style.position || 'relative';
  container.style.overflow = container.style.overflow || 'auto';
  container.replaceChildren();

  const spacer = document.createElement('div');
  spacer.style.position = 'relative';
  spacer.style.width = '100%';
  spacer.style.pointerEvents = 'none';

  const inner = document.createElement('div');
  inner.style.position = 'absolute';
  inner.style.left = '0';
  inner.style.right = '0';
  inner.style.top = '0';
  inner.style.pointerEvents = 'auto';
  if (className) inner.className = className;

  spacer.appendChild(inner);
  container.appendChild(spacer);

  let raf = 0;
  let lastStart = -1;
  let lastEnd = -1;
  let destroyed = false;

  const totalHeight = (count: number): number => count * rowHeight;

  function render(): void {
    if (destroyed) return;
    const items = getItems();
    const count = items.length;
    const height = totalHeight(count);
    spacer.style.height = `${height}px`;

    if (count === 0) {
      container.scrollTop = 0;
      spacer.style.height = `${Math.max(64, container.clientHeight || 64)}px`;
      inner.replaceChildren();
      inner.style.transform = 'translateY(0)';
      lastStart = lastEnd = -1;
      const empty = document.createElement('div');
      empty.className = 'hint';
      empty.style.padding = '16px';
      empty.style.pointerEvents = 'none';
      empty.textContent = 'موردی برای نمایش نیست.';
      inner.appendChild(empty);
      return;
    }

    const viewHeight = Math.max(1, container.clientHeight || 400);
    // بعد از فیلتر یا حذف داده، scrollTop قبلی ممکن است خارج از محدوده شود.
    // آن را پیش از محاسبه بازه رندر به آخرین موقعیت معتبر محدود می‌کنیم.
    const maxScrollTop = Math.max(0, height - viewHeight);
    const scrollTop = Math.min(Math.max(0, container.scrollTop), maxScrollTop);
    if (container.scrollTop !== scrollTop) container.scrollTop = scrollTop;

    let start = Math.floor(scrollTop / rowHeight) - overscan;
    let end = Math.ceil((scrollTop + viewHeight) / rowHeight) + overscan;
    start = Math.max(0, Math.min(count - 1, start));
    end = Math.max(start + 1, Math.min(count, end));

    if (start === lastStart && end === lastEnd) return;
    lastStart = start;
    lastEnd = end;
    inner.style.transform = `translateY(${start * rowHeight}px)`;

    const fragment = document.createDocumentFragment();
    for (let index = start; index < end; index++) {
      // عمداً node قبلی را با innerHTML جایگزین نمی‌کنیم؛ چون listenerها
      // و closureهای renderRow با انتقال HTML منتقل نمی‌شوند و stale می‌مانند.
      const row = renderRow(items[index], index);
      row.style.height = `${rowHeight}px`;
      row.style.boxSizing = 'border-box';
      const key = options.getKey?.(items[index], index);
      if (key != null) row.dataset.vk = key;
      fragment.appendChild(row);
    }
    inner.replaceChildren(fragment);
  }

  function schedule(): void {
    if (destroyed || raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      render();
    });
  }

  const onScroll = () => schedule();
  container.addEventListener('scroll', onScroll, { passive: true });

  let resizeObserver: ResizeObserver | null = null;
  if (typeof ResizeObserver !== 'undefined') {
    resizeObserver = new ResizeObserver(() => schedule());
    resizeObserver.observe(container);
  }

  render();

  return {
    refresh() {
      lastStart = lastEnd = -1;
      schedule();
    },
    scrollToIndex(index: number, align: 'start' | 'center' | 'end' = 'center') {
      const items = getItems();
      if (!items.length) return;
      const safeIndex = Math.max(0, Math.min(items.length - 1, Math.floor(index)));
      let top = safeIndex * rowHeight;
      if (align === 'center') {
        top = top - container.clientHeight / 2 + rowHeight / 2;
      } else if (align === 'end') {
        top = top - container.clientHeight + rowHeight;
      }
      const maxScrollTop = Math.max(0, totalHeight(items.length) - container.clientHeight);
      container.scrollTop = Math.max(0, Math.min(maxScrollTop, top));
      schedule();
    },
    destroy() {
      if (destroyed) return;
      destroyed = true;
      container.removeEventListener('scroll', onScroll);
      resizeObserver?.disconnect();
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
      container.replaceChildren();
    },
  };
}
