/** محاسبات خالص و مستقل تخفیف کل فاکتور؛ تمام مبالغ بر حسب ریال صحیح هستند. */
export type InvoiceDiscountType = 'percent' | 'amount';

/** درصد به‌صورت صدم درصد (basis points) نگهداری می‌شود؛ مبلغ ثابت به ریال است. */
export function calculateInvoiceDiscountRial(
  subtotalRial: number,
  type: InvoiceDiscountType,
  value: number,
): number {
  if (!Number.isSafeInteger(subtotalRial) || subtotalRial < 0) throw new Error('جمع فاکتور برای محاسبه تخفیف معتبر نیست.');
  if (!Number.isSafeInteger(value) || value < 0) throw new Error('مقدار تخفیف باید عدد صحیح و غیرمنفی باشد.');
  if (type === 'percent') {
    if (value > 9999) throw new Error('درصد تخفیف کل فاکتور باید کمتر از ۱۰۰ درصد باشد.');
    return Number((BigInt(subtotalRial) * BigInt(value) + 5000n) / 10000n);
  }
  if (type !== 'amount') throw new Error('نوع تخفیف کل فاکتور معتبر نیست.');
  if (value > subtotalRial || (subtotalRial > 0 && value >= subtotalRial)) {
    throw new Error('تخفیف کل فاکتور باید کمتر از جمع اقلام پس از تخفیف ردیف‌ها باشد.');
  }
  return value;
}

/** تخصیص دقیق و قطعی تخفیف به ردیف‌ها؛ جمع سهم‌ها همیشه دقیقاً برابر تخفیف است. */
export function allocateInvoiceDiscountRial(lineTotals: number[], discountRial: number): number[] {
  const subtotal = lineTotals.reduce((sum, amount) => sum + amount, 0);
  if (!Number.isSafeInteger(subtotal) || subtotal < 0 || !Number.isSafeInteger(discountRial) || discountRial < 0 || discountRial > subtotal) {
    throw new Error('مبالغ برای تخصیص تخفیف کل فاکتور معتبر نیستند.');
  }
  if (!discountRial || !subtotal) return lineTotals.map(() => 0);
  const shares: number[] = [];
  let allocated = 0;
  let largestIndex = 0;
  lineTotals.forEach((amount, index) => {
    if (!Number.isSafeInteger(amount) || amount < 0) throw new Error('مبلغ یکی از ردیف‌های فاکتور معتبر نیست.');
    if (amount > (lineTotals[largestIndex] || 0)) largestIndex = index;
    const share = Number((BigInt(discountRial) * BigInt(amount)) / BigInt(subtotal));
    shares.push(share);
    allocated += share;
  });
  shares[largestIndex] += discountRial - allocated;
  return shares;
}
