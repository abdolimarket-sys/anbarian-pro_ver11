/**
 * Trial lifecycle service.
 * One authority for trial dates and rollback detection. Android persists the anchor
 * outside WebView storage; web builds use a versioned local fallback.
 * This is tamper-resistance, not a substitute for a server-issued signed trial lease.
 */
import { Capacitor, registerPlugin } from '@capacitor/core';
import { evaluateTrialStatus } from './trial-license-core';

const ROLLBACK_TOLERANCE_MS = 60 * 60 * 1000;
const TRIAL_STORAGE_KEY = 'anbar_trial_anchor_v1';

export interface TrialAnchor {
  schemaVersion: 1;
  firstAt: string;
  lastSeenAt: string;
  clockTamper: boolean;
  source: 'android-native' | 'web-local';
}

export interface TrialStatus {
  firstAt: string;
  trialEnd: string;
  trialLeft: number;
  trialActive: boolean;
  clockTamper: boolean;
}

interface NativeTrialGuard {
  getOrCreateState(options: { legacyFirstAt?: string; legacyLastSeenAt?: string; legacyClockTamper?: boolean }): Promise<{
    firstAt: string;
    lastSeenAt: string;
    clockTamper: boolean;
    deviceFingerprint: string;
  }>;
}

const NativeTrialGuardPlugin = registerPlugin<NativeTrialGuard>('TrialGuard');
let currentAnchor: TrialAnchor | null = null;
let initialization: Promise<TrialStatus> | null = null;
let lastNativeSyncAt = 0;

function validIso(value: unknown): value is string {
  return typeof value === 'string' && Number.isFinite(Date.parse(value)) && Date.parse(value) > 0;
}

function legacyInstallMeta(): { firstAt?: string; lastSeenAt?: string; clockTamper: boolean } {
  try {
    const legacy = JSON.parse(localStorage.getItem('anbar_install') || 'null') as { firstAt?: unknown; lastSeen?: unknown; clockTamper?: unknown } | null;
    return {
      firstAt: validIso(legacy?.firstAt) ? legacy!.firstAt as string : undefined,
      lastSeenAt: typeof legacy?.lastSeen === 'number' && legacy.lastSeen > 0 ? new Date(legacy.lastSeen).toISOString() : undefined,
      clockTamper: legacy?.clockTamper === true,
    };
  } catch { return { clockTamper: false }; }
}

function makeWebAnchor(): TrialAnchor {
  const now = Date.now();
  let parsed: Partial<TrialAnchor> | null = null;
  let existed = false;
  try {
    const raw = localStorage.getItem(TRIAL_STORAGE_KEY);
    existed = raw !== null;
    parsed = raw ? JSON.parse(raw) as Partial<TrialAnchor> : null;
  } catch { parsed = null; }

  // A corrupt existing record must not silently grant a fresh trial.
  if (existed && (!parsed || parsed.schemaVersion !== 1 || !validIso(parsed.firstAt) || !validIso(parsed.lastSeenAt))) {
    const firstAt = validIso(parsed?.firstAt) ? parsed!.firstAt! : new Date(0).toISOString();
    return { schemaVersion: 1, firstAt, lastSeenAt: new Date(Math.max(now, Date.parse(parsed?.lastSeenAt || '') || 0)).toISOString(), clockTamper: true, source: 'web-local' };
  }

  const legacy = legacyInstallMeta();
  const firstAt = validIso(parsed?.firstAt)
    ? (legacy.firstAt && Date.parse(legacy.firstAt) < Date.parse(parsed!.firstAt!) ? legacy.firstAt : parsed!.firstAt!)
    : (legacy.firstAt || new Date(now).toISOString());
  const previous = validIso(parsed?.lastSeenAt) ? Date.parse(parsed!.lastSeenAt!) : (legacy.lastSeenAt ? Date.parse(legacy.lastSeenAt) : 0);
  let clockTamper = parsed ? !!parsed.clockTamper : legacy.clockTamper;
  if (previous && now < previous - ROLLBACK_TOLERANCE_MS) clockTamper = true;
  else if (clockTamper && now >= previous) clockTamper = false;
  return {
    schemaVersion: 1,
    firstAt,
    lastSeenAt: new Date(Math.max(now, previous)).toISOString(),
    clockTamper,
    source: 'web-local',
  };
}

function persistWebAnchor(anchor: TrialAnchor): void {
  try { localStorage.setItem(TRIAL_STORAGE_KEY, JSON.stringify(anchor)); }
  catch { /* The in-memory state remains valid for this session; no false persistence claim. */ }
}

function statusFromAnchor(anchor: TrialAnchor, now = Date.now()): TrialStatus {
  return evaluateTrialStatus(anchor, now);
}

/** Call once during application bootstrap, before applying module entitlements. */
export function initializeTrialLicense(): Promise<TrialStatus> {
  if (initialization) return initialization;
  initialization = (async () => {
    if (Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android') {
      try {
        const native = await NativeTrialGuardPlugin.getOrCreateState({ legacyFirstAt: legacyInstallMeta().firstAt, legacyLastSeenAt: legacyInstallMeta().lastSeenAt, legacyClockTamper: legacyInstallMeta().clockTamper });
        if (!validIso(native.firstAt) || !validIso(native.lastSeenAt)) throw new Error('invalid_native_trial_state');
        currentAnchor = {
          schemaVersion: 1,
          firstAt: native.firstAt,
          lastSeenAt: native.lastSeenAt,
          clockTamper: !!native.clockTamper,
          source: 'android-native',
        };
        lastNativeSyncAt = Date.now();
        persistWebAnchor(currentAnchor);
        return statusFromAnchor(currentAnchor);
      } catch (error) {
        console.warn('[Anbarin] native trial guard unavailable; using local fallback:', error);
      }
    }
    currentAnchor = makeWebAnchor();
    persistWebAnchor(currentAnchor);
    return statusFromAnchor(currentAnchor);
  })().catch((error) => {
    initialization = null;
    throw error;
  });
  return initialization;
}

/** Synchronous read for existing entitlement guards; bootstrap initializes native state first. */
export function getTrialStatus(now = Date.now()): TrialStatus {
  if (!currentAnchor) {
    currentAnchor = makeWebAnchor();
    persistWebAnchor(currentAnchor);
  }
  const previous = Date.parse(currentAnchor.lastSeenAt);
  if (previous && now < previous - ROLLBACK_TOLERANCE_MS) {
    currentAnchor = { ...currentAnchor, clockTamper: true };
    persistWebAnchor(currentAnchor);
  } else if (currentAnchor.source === 'web-local' && currentAnchor.clockTamper && previous > 0 && now >= previous) {
    currentAnchor = { ...currentAnchor, clockTamper: false, lastSeenAt: new Date(now).toISOString() };
    persistWebAnchor(currentAnchor);
  } else if (Number.isFinite(now) && now > previous) {
    currentAnchor = { ...currentAnchor, lastSeenAt: new Date(now).toISOString() };
    persistWebAnchor(currentAnchor);
  }
  // Persist a native checkpoint periodically as well as on app foreground.
  if (currentAnchor.source === 'android-native' && now - lastNativeSyncAt > 30_000) {
    lastNativeSyncAt = now;
    void refreshTrialLicense();
  }
  return statusFromAnchor(currentAnchor, now);
}

/** Reconcile the native anchor whenever the app returns to the foreground. */
export async function refreshTrialLicense(): Promise<TrialStatus> {
  if (Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android') {
    try {
      const native = await NativeTrialGuardPlugin.getOrCreateState({ legacyFirstAt: currentAnchor?.firstAt || legacyInstallMeta().firstAt, legacyLastSeenAt: currentAnchor?.lastSeenAt || legacyInstallMeta().lastSeenAt, legacyClockTamper: currentAnchor?.clockTamper || legacyInstallMeta().clockTamper });
      if (!validIso(native.firstAt) || !validIso(native.lastSeenAt)) throw new Error('invalid_native_trial_state');
      currentAnchor = {
        schemaVersion: 1,
        firstAt: native.firstAt,
        lastSeenAt: native.lastSeenAt,
        clockTamper: !!native.clockTamper,
        source: 'android-native',
      };
      lastNativeSyncAt = Date.now();
      persistWebAnchor(currentAnchor);
      return statusFromAnchor(currentAnchor);
    } catch (error) {
      console.warn('[Anbarin] native trial refresh failed:', error);
    }
  }
  currentAnchor = makeWebAnchor();
  persistWebAnchor(currentAnchor);
  return statusFromAnchor(currentAnchor);
}

