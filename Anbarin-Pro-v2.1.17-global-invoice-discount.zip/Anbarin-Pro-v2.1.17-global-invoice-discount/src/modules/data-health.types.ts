/** قراردادهای پایدار مرکز سلامت داده؛ مستقل از رابط کاربری و ذخیره‌سازی. */
export type HealthLevel = 'error' | 'warning' | 'info' | 'ok';
export type HealthEntityType = 'product' | 'journal' | 'invoice' | 'balance' | 'party' | 'transaction' | 'cash-account' | 'system';
export type HealthAction = { type: 'edit-product'; entityId: string; label: string };
export interface HealthIssueDetail {
  entityType: HealthEntityType;
  entityId?: string;
  primary: string;
  secondary?: string;
  action?: HealthAction;
}
export interface HealthFinding {
  /** شناسه پایدار ماشینی؛ برای آزمون، فیلتر، ترجمه و توسعه آینده */
  code: string;
  level: HealthLevel;
  title: string;
  detail: string;
  /** تعداد موارد معیوب، نه لزوماً تعداد گروه‌های خطا */
  count?: number;
  /** جزئیات رکوردهای درگیر؛ تشخیص فقط‌خواندنی است */
  items?: HealthIssueDetail[];
  remediation?: string;
}
export interface HealthReport {
  checkedAt: string;
  findings: HealthFinding[];
  totals: { errors: number; warnings: number; info: number; ok: number };
}
