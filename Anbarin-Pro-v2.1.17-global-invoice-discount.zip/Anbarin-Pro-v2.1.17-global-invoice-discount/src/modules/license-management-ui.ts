/** داشبورد شفاف وضعیت مجوزها؛ فقط نمایش است و هیچ مجوزی صادر یا تغییر نمی‌دهد. */
import { getLicenseState } from './license';
import { getOfflineLicense } from './offline-license';
import { ENTITLEMENT_REGISTRY, getActiveEntitlements } from './license-modules';

function escapeHtml(value: unknown): string {
  const entities: Record<string, string> = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&#39;' };
  return String(value ?? '').replace(/[&<>\"']/g, (char) => entities[char] || char);
}

function statusPill(active: boolean): string {
  const color = active ? '#16834a' : 'var(--text-soft)';
  const label = active ? 'فعال' : 'نیازمند مجوز';
  return `<span style="white-space:nowrap;border:1px solid ${active ? 'rgba(22,131,74,.35)' : 'var(--border)'};border-radius:999px;padding:3px 9px;font-size:.75rem;color:${color}">${label}</span>`;
}

export function renderLicenseManagementUI(): void {
  const summary = document.getElementById('licenseEntitlementSummary');
  const list = document.getElementById('licenseEntitlementList');
  if (!summary || !list) return;

  const state = getLicenseState();
  const offline = getOfflineLicense();
  const active = new Set<string>(getActiveEntitlements());
  const source = offline ? 'لایسنس آفلاین امضاشده' : state.licensed ? 'لایسنس فعال' : state.trialActive ? 'دوره آزمایشی' : 'دسترسی پایه رایگان';
  const customer = offline?.customerName || state.license?.org || '—';
  const licenseId = offline?.licenseId || '—';
  const expiry = offline?.licenseTerm === 'perpetual' ? 'دائمی، بدون تاریخ انقضا' : offline?.validUntil || state.license?.exp || (state.trialActive ? state.trialEnd.slice(0, 10) : 'بدون انقضا برای شمارش پایه');
  summary.innerHTML = `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:8px">
    <div><small style="color:var(--text-soft)">نوع دسترسی</small><div><strong>${escapeHtml(source)}</strong></div></div>
    <div><small style="color:var(--text-soft)">مشتری / سازمان</small><div><strong>${escapeHtml(customer)}</strong></div></div>
    <div><small style="color:var(--text-soft)">شناسه مجوز</small><div style="font-family:monospace;overflow-wrap:anywhere">${escapeHtml(licenseId)}</div></div>
    <div><small style="color:var(--text-soft)">اعتبار تا</small><div><strong>${escapeHtml(expiry)}</strong></div></div>
  </div>`;

  const entries = Object.values(ENTITLEMENT_REGISTRY);
  list.innerHTML = entries.map((entry) => {
    const enabled = active.has(entry.id);
    const dependencyText = entry.dependencies?.length ? `وابسته به: ${entry.dependencies.map((id) => ENTITLEMENT_REGISTRY[id]?.label || id).join('، ')}` : 'بدون وابستگی';
    const kind = entry.module ? (entry.module === 'count' ? 'ماژول انبار' : 'ماژول حسابداری') : 'قابلیت مستقل';
    return `<article style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px;border:1px solid var(--border);border-radius:10px;min-width:0">
      <div style="min-width:0"><div style="font-weight:700">${escapeHtml(entry.label)}</div><div style="font-size:.74rem;color:var(--text-soft);overflow-wrap:anywhere">${escapeHtml(kind)} · ${escapeHtml(dependencyText)}</div><code style="font-size:.68rem;color:var(--text-soft)">${escapeHtml(entry.id)}</code></div>
      ${statusPill(enabled)}
    </article>`;
  }).join('');

  const device = document.getElementById('deviceIdDisplay') as HTMLInputElement | null;
  if (device && !device.value) device.value = state.deviceId;
}
