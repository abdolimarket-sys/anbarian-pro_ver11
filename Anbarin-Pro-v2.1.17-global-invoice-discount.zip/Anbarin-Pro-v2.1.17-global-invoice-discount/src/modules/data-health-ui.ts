/** رابط کاربری مرکز سلامت؛ فقط نمایش و فراخوانی مسیرهای رسمی ماژول‌ها. */
import { esc } from '@/utils/helpers';
import type { HealthLevel } from './data-health.types';
import { collectHealthReport } from './data-health-service';

export async function renderDataHealth(containerId='dataHealthWorkspace'):Promise<void>{
  const host=document.getElementById(containerId);if(!host)return;
  host.innerHTML='<p class="hint">در حال بررسی سلامت داده‌ها...</p>';
  try{
    const report=await collectHealthReport();
    const labels:Record<HealthLevel,string>={error:'خطا',warning:'هشدار',info:'اطلاعات',ok:'سالم'};
    const hasPending = report.findings.some(f => f.title === 'عملیات مالی نیمه‌تمام' || (f.detail.includes('شماره:') && f.detail.includes('محل:')));
    const rows=report.findings.map(f=>{
      const details = f.items?.length ? `<details class="health-details"><summary>مشاهده جزئیات (${f.items.length} رکورد)</summary><div class="health-detail-list">${f.items.map(item=>`<div class="health-detail-row"><div><b>${esc(item.primary)}</b><p>${esc(item.secondary || '')}</p></div>${item.action?.type==='edit-product'?`<button type="button" class="btn secondary health-edit-product" data-product-id="${esc(item.action.entityId)}">${esc(item.action.label)}</button>`:''}</div>`).join('')}</div></details>` : '';
      return `<article class="health-finding health-${f.level}" data-health-code="${esc(f.code)}"><div class="health-finding-main"><b>${esc(labels[f.level])} — ${esc(f.title)}</b><p style="white-space:pre-wrap">${esc(f.detail)}</p>${f.remediation?`<p class="health-remediation"><b>روش رسیدگی:</b> ${esc(f.remediation)}</p>`:''}${details}</div>${f.count!==undefined?`<strong class="health-count">${f.count}</strong>`:''}</article>`;
    }).join('');
    const pendingActions = hasPending ? `
      <div class="row" style="gap:8px;margin:8px 0;flex-wrap:wrap;padding:10px;border:1px solid var(--border-color,#ddd);border-radius:8px;background:var(--bg-soft,#f8f8f8)">
        <p class="hint" style="margin:0 0 6px;width:100%">عملیات مالی نیمه‌تمام شناسایی شد. بازیابی خودکار را دوباره امتحان کنید یا در صورت اطمینان، فقط نشانگر عملیات را آزاد کنید. این کار روی موجودی و اسناد مالی اثر نمی‌گذارد.</p>
        <button type="button" class="btn" id="healthRetryRecoveryBtn">تلاش مجدد بازیابی</button>
        <button type="button" class="btn secondary" id="healthDiscardPendingBtn">انصراف از عملیات نیمه‌تمام</button>
      </div>` : '';
    host.innerHTML=`<div class="health-summary"><div><b>${report.totals.errors}</b><span>خطا</span></div><div><b>${report.totals.warnings}</b><span>هشدار</span></div><div><b>${report.totals.ok}</b><span>مورد سالم</span></div></div>
      <p class="hint">زمان بررسی: ${esc(new Date(report.checkedAt).toLocaleString('fa-IR'))} — بررسی ساختاری فقط‌خواندنی است. همگام‌سازی موجودی کارت از بهای تمام‌شده با دکمه زیر انجام می‌شود.</p>
      <div class="row" style="gap:8px;margin:8px 0;flex-wrap:wrap">
        <button type="button" class="btn secondary" id="healthRecheckBtn">بررسی دوباره</button>
        <button type="button" class="btn" id="healthSyncStockBtn">همگام‌سازی موجودی از بهای تمام‌شده</button>
      </div>
      <details style="margin:12px 0;border:1px solid #c62828;border-radius:8px;padding:10px;background:#fff5f5">
        <summary style="cursor:pointer;color:#b71c1c;font-weight:600">منطقه خطر — ریست کلی داده‌های عملیاتی و مالی</summary>
        <p class="hint" style="margin:8px 0">
          این عمل موجودی کالا، فاکتورها، اسناد حسابداری، چک‌ها، بهای تمام‌شده و پشتیبان‌های خودکار را پاک می‌کند.
          لایسنس، تنظیمات پایه و کاربران حفظ می‌شوند. قبل از پاک‌سازی یک نسخه اضطراری داخلی گرفته می‌شود.
          این عمل برگشت‌پذیر آسان نیست.
        </p>
        <label class="field" style="display:block;margin:8px 0">
          برای تأیید، عبارت زیر را دقیقاً بنویسید:
          <b>پاک کردن همه داده‌ها</b>
          <input id="factoryResetConfirmInput" type="text" placeholder="پاک کردن همه داده‌ها" autocomplete="off" style="width:100%;margin-top:6px" />
        </label>
        <button type="button" class="btn" id="healthFactoryResetBtn" style="background:#c62828;color:#fff;border-color:#c62828">
          ریست کلی داده‌ها
        </button>
      </details>
      ${pendingActions}
      ${rows}`;
    host.querySelector('#healthRecheckBtn')?.addEventListener('click',()=>{void renderDataHealth(containerId);});
    host.querySelectorAll<HTMLButtonElement>('.health-edit-product').forEach(button=>button.addEventListener('click',async()=>{
      const id=button.dataset.productId;
      if(!id)return;
      try {
        const { openProductModal } = await import('./products-ui');
        await openProductModal(id);
      } catch(e) {
        const { toast } = await import('./ui');
        toast(e instanceof Error?e.message:'فرم ویرایش کالا باز نشد','error');
      }
    }));
    host.querySelector('#healthSyncStockBtn')?.addEventListener('click',async()=>{
      try{
        const { syncProductCardsFromCostingTruth } = await import('./inventory-truth');
        const r=await syncProductCardsFromCostingTruth();
        const { toast } = await import('./ui');
        toast(r.updated?`موجودی ${r.updated} کالا همگام شد.`:'همه کارت‌ها با بهای تمام‌شده هم‌خوان بودند.','success');
        await renderDataHealth(containerId);
      }catch(e){
        const { toast } = await import('./ui');
        toast(e instanceof Error?e.message:'همگام‌سازی انجام نشد','error');
      }
    });


    // ریست کلی — فقط پس از تأیید متنی؛ نسخه اضطراری گرفته می‌شود
    host.querySelector('#healthFactoryResetBtn')?.addEventListener('click', async () => {
      const input = host.querySelector('#factoryResetConfirmInput') as HTMLInputElement | null;
      const phrase = (input?.value || '').trim();
      const { confirmAction } = await import('./ui');
      const first = await confirmAction(
        'هشدار نهایی\n\n' +
        'همه داده‌های موجودی، مالی، فاکتور، چک و بهای تمام‌شده پاک می‌شوند.\n' +
        'لایسنس و تنظیمات پایه حفظ می‌گردند.\n\n' +
        'ادامه می‌دهید؟'
      );
      if (!first) return;
      try {
        const { factoryResetFinancialAndOperationalData } = await import('./financial-commit');
        const { logAudit } = await import('./state');
        const { toast } = await import('./ui');
        const result = await factoryResetFinancialAndOperationalData(phrase);
        if (!result.ok) {
          toast(result.message, 'error');
          return;
        }
        try {
          logAudit('factory_reset_financial_operational', {
            clearedKeys: result.clearedKeys,
            backedUp: result.backedUp,
          });
        } catch { /* ignore audit failure */ }
        toast(result.message + ' برنامه تازه بارگذاری می‌شود.', 'success');
        setTimeout(() => { window.location.reload(); }, 1200);
      } catch (e) {
        const { toast } = await import('./ui');
        toast(e instanceof Error ? e.message : 'ریست انجام نشد', 'error');
      }
    });

    // تلاش مجدد بازیابی — فقط منطق موجود recoverPendingCommerceOperation
    host.querySelector('#healthRetryRecoveryBtn')?.addEventListener('click', async () => {
      try {
        const { recoverPendingCommerceOperation } = await import('./accounting-commerce');
        const { toast } = await import('./ui');
        const result = await recoverPendingCommerceOperation();
        if (result.status === 'recovered') {
          toast(result.message || 'عملیات نیمه‌تمام بازیابی شد.', 'success');
        } else if (result.status === 'blocked') {
          toast(result.message || 'بازیابی ممکن نشد.', 'error');
        } else {
          toast('عملیات نیمه‌تمامی برای بازیابی وجود نداشت.', 'info');
        }
        await renderDataHealth(containerId);
      } catch (e) {
        const { toast } = await import('./ui');
        toast(e instanceof Error ? e.message : 'بازیابی انجام نشد', 'error');
      }
    });

    // انصراف آگاهانه — فقط نشانگر را آزاد می‌کند؛ موجودی و مالی دست نخورده می‌مانند
    host.querySelector('#healthDiscardPendingBtn')?.addEventListener('click', async () => {
      const { confirmAction } = await import('./ui');
      const confirmed = await confirmAction(
        'انصراف از عملیات مالی نیمه‌تمام\n\n' +
        'این کار فقط نشانگر عملیات را آزاد می‌کند.\n' +
        'هیچ تغییری در موجودی کالا، اسناد حسابداری یا تراکنش‌های مالی ایجاد نمی‌شود.\n\n' +
        'آیا مطمئن هستید؟'
      );
      if (!confirmed) return;
      try {
        const { discardPendingCommerceOperation } = await import('./financial-commit');
        const { logAudit } = await import('./state');
        const { toast } = await import('./ui');
        const result = await discardPendingCommerceOperation('انصراف از صفحه سلامت داده');
        if (result.status === 'discarded' && result.operation) {
          try {
            logAudit('discard_pending_commerce_operation', {
              operationId: result.operation.id,
              kind: result.operation.kind,
              invoiceId: result.operation.invoiceId,
              transactionId: result.operation.transactionId,
              startedAt: result.operation.startedAt,
              attempts: result.operation.attempts,
            });
          } catch { /* audit نباید مسیر اصلی را بشکند */ }
          toast('نشانگر عملیات نیمه‌تمام آزاد شد. موجودی و اسناد مالی تغییر نکردند.', 'success');
        } else {
          toast('عملیات نیمه‌تمامی برای انصراف وجود نداشت.', 'info');
        }
        await renderDataHealth(containerId);
      } catch (e) {
        const { toast } = await import('./ui');
        toast(e instanceof Error ? e.message : 'انصراف انجام نشد', 'error');
      }
    });
  }catch(e){host.innerHTML=`<p class="hint">بررسی کامل نشد: ${esc(e instanceof Error?e.message:'خطای نامشخص')}</p>`;}
}
