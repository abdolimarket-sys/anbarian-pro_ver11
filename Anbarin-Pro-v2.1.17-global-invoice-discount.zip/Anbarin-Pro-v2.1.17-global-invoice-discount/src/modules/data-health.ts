/** API عمومی مرکز سلامت داده‌ها؛ پیاده‌سازی دامنه، سرویس و UI مستقل نگه داشته شده‌اند. */
export { analyzeHealth } from './data-health-rules';
export { collectHealthReport } from './data-health-service';
export { renderDataHealth } from './data-health-ui';
export type { HealthLevel, HealthReport, HealthFinding, HealthIssueDetail, HealthEntityType, HealthAction } from './data-health.types';
