/** سازگاری با کدهای قدیمی؛ کلید فعال و نسل‌های قبلی در issuer-public-keys.json نگهداری می‌شوند. */
import issuerKeyRing from './issuer-public-keys.json';
export const ISSUER_PUBLIC_KEY_PEM = issuerKeyRing.keys[issuerKeyRing.activeKeyId as keyof typeof issuerKeyRing.keys];
